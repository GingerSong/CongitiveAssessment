export interface Option {
  id: string;
  text: string;
  value: number;
}

export interface SequenceData {
  items: string[];
  displayTime: number;
  question: string;
  options: Option[];
}

export interface ConnectionData {
  nodes: ConnectionNode[];
  correctSequence: string[];
}

export interface ConnectionNode {
  id: string;
  text: string;
  x: number;
  y: number;
}

export interface QuestionData {
  id: string;
  text: string;
  description?: string;
  type: 'single' | 'multiple' | 'memory' | 'visual' | 'sequence' | 'connection';
  options: Option[];
  visualAid?: string;
  sequenceData?: SequenceData;
  connectionData?: ConnectionData;
  dynamicOptions?: boolean;
  getDynamicOptions?: () => Option[];
}