import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { nanoid } from 'nanoid';

// 测试记录类型
export interface TestRecord {
  id: string;
  date: string;
  type: 'hama' | 'hamd' | 'mmse' | 'moca';
  score: number;
  interpretation: string;
}

// 健康信息类型
export interface HealthInfo {
  id: string;
  type: 'medication' | 'appointment' | 'note';
  title: string;
  description: string;
  date: string;
  reminder?: {
    enabled: boolean;
    frequency: 'once' | 'daily' | 'weekly' | 'monthly';
    time?: string;
  };
}

// 提醒类型
export interface Reminder {
  id: string;
  title: string;
  description: string;
  date: string;
  time: string;
  type: 'test' | 'medication' | 'appointment' | 'activity';
  completed: boolean;
}

// 用户档案类型
export interface UserProfile {
  id: string;
  name: string;
  gender: 'male' | 'female' | 'other';
  birthDate: string;
  education: string;
  testRecords: TestRecord[];
  healthInfo: HealthInfo[];
  reminders: Reminder[];
}

interface ProfileContextType {
  currentProfile: UserProfile | null;
  profiles: UserProfile[];
  createProfile: (profile: Omit<UserProfile, 'id' | 'testRecords' | 'healthInfo' | 'reminders'>) => void;
  updateProfile: (id: string, updates: Partial<UserProfile>) => void;
  deleteProfile: (id: string) => void;
  setCurrentProfile: (id: string | null) => void;
  addTestRecord: (profileId: string, record: Omit<TestRecord, 'id'>) => void;
  addHealthInfo: (profileId: string, info: Omit<HealthInfo, 'id'>) => void;
  addReminder: (profileId: string, reminder: Omit<Reminder, 'id'>) => void;
  updateReminder: (profileId: string, reminderId: string, updates: Partial<Reminder>) => void;
  deleteHealthInfo: (profileId: string, infoId: string) => void;
  deleteReminder: (profileId: string, reminderId: string) => void;
  getRiskAnalysis: (profileId: string) => { level: 'low' | 'medium' | 'high'; factors: string[] };
}

const ProfileContext = createContext<ProfileContextType | undefined>(undefined);

export const ProfileProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [profiles, setProfiles] = useState<UserProfile[]>([]);
  const [currentProfile, setCurrentProfileState] = useState<UserProfile | null>(null);

  // 从本地存储加载数据
  useEffect(() => {
    const savedProfiles = localStorage.getItem('userProfiles');
    const currentProfileId = localStorage.getItem('currentProfileId');
    
    if (savedProfiles) {
      const parsedProfiles = JSON.parse(savedProfiles);
      setProfiles(parsedProfiles);
      
      if (currentProfileId) {
        const profile = parsedProfiles.find((p: UserProfile) => p.id === currentProfileId);
        if (profile) {
          setCurrentProfileState(profile);
        }
      }
    }
  }, []);

  // 保存数据到本地存储
  useEffect(() => {
    if (profiles.length > 0) {
      localStorage.setItem('userProfiles', JSON.stringify(profiles));
    }
    
    if (currentProfile) {
      localStorage.setItem('currentProfileId', currentProfile.id);
    }
  }, [profiles, currentProfile]);

  // 创建新档案
  const createProfile = (profile: Omit<UserProfile, 'id' | 'testRecords' | 'healthInfo' | 'reminders'>) => {
    const newProfile: UserProfile = {
      ...profile,
      id: nanoid(),
      testRecords: [],
      healthInfo: [],
      reminders: []
    };
    
    setProfiles(prev => [...prev, newProfile]);
    setCurrentProfileState(newProfile);
  };

  // 更新档案
  const updateProfile = (id: string, updates: Partial<UserProfile>) => {
    setProfiles(prev => 
      prev.map(profile => 
        profile.id === id ? { ...profile, ...updates } : profile
      )
    );
    
    if (currentProfile?.id === id) {
      setCurrentProfileState(prev => prev ? { ...prev, ...updates } : prev);
    }
  };

  // 删除档案
  const deleteProfile = (id: string) => {
    setProfiles(prev => prev.filter(profile => profile.id !== id));
    
    if (currentProfile?.id === id) {
      setCurrentProfileState(null);
      localStorage.removeItem('currentProfileId');
    }
  };

  // 设置当前档案
  const setCurrentProfile = (id: string | null) => {
    if (id === null) {
      setCurrentProfileState(null);
      localStorage.removeItem('currentProfileId');
      return;
    }
    
    const profile = profiles.find(p => p.id === id);
    if (profile) {
      setCurrentProfileState(profile);
      localStorage.setItem('currentProfileId', id);
    }
  };

  // 添加测试记录
  const addTestRecord = (profileId: string, record: Omit<TestRecord, 'id'>) => {
    const newRecord: TestRecord = {
      ...record,
      id: nanoid()
    };
    
    setProfiles(prev => 
      prev.map(profile => 
        profile.id === profileId 
          ? { ...profile, testRecords: [...profile.testRecords, newRecord] } 
          : profile
      )
    );
    
    if (currentProfile?.id === profileId) {
      setCurrentProfileState(prev => 
        prev ? { ...prev, testRecords: [...prev.testRecords, newRecord] } : prev
      );
    }
  };

  // 添加健康信息
  const addHealthInfo = (profileId: string, info: Omit<HealthInfo, 'id'>) => {
    const newInfo: HealthInfo = {
      ...info,
      id: nanoid()
    };
    
    setProfiles(prev => 
      prev.map(profile => 
        profile.id === profileId 
          ? { ...profile, healthInfo: [...profile.healthInfo, newInfo] } 
          : profile
      )
    );
    
    if (currentProfile?.id === profileId) {
      setCurrentProfileState(prev => 
        prev ? { ...prev, healthInfo: [...prev.healthInfo, newInfo] } : prev
      );
    }
  };

  // 删除健康信息
  const deleteHealthInfo = (profileId: string, infoId: string) => {
    setProfiles(prev => 
      prev.map(profile => 
        profile.id === profileId 
          ? { ...profile, healthInfo: profile.healthInfo.filter(info => info.id !== infoId) } 
          : profile
      )
    );
    
    if (currentProfile?.id === profileId) {
      setCurrentProfileState(prev => 
        prev ? { ...prev, healthInfo: prev.healthInfo.filter(info => info.id !== infoId) } : prev
      );
    }
  };

  // 添加提醒
  const addReminder = (profileId: string, reminder: Omit<Reminder, 'id'>) => {
    const newReminder: Reminder = {
      ...reminder,
      id: nanoid()
    };
    
    setProfiles(prev => 
      prev.map(profile => 
        profile.id === profileId 
          ? { ...profile, reminders: [...profile.reminders, newReminder] } 
          : profile
      )
    );
    
    if (currentProfile?.id === profileId) {
      setCurrentProfileState(prev => 
        prev ? { ...prev, reminders: [...prev.reminders, newReminder] } : prev
      );
    }
  };

  // 更新提醒
  const updateReminder = (profileId: string, reminderId: string, updates: Partial<Reminder>) => {
    setProfiles(prev => 
      prev.map(profile => 
        profile.id === profileId 
          ? { 
              ...profile, 
              reminders: profile.reminders.map(reminder => 
                reminder.id === reminderId ? { ...reminder, ...updates } : reminder
              ) 
            } 
          : profile
      )
    );
    
    if (currentProfile?.id === profileId) {
      setCurrentProfileState(prev => 
        prev ? { 
          ...prev, 
          reminders: prev.reminders.map(reminder => 
            reminder.id === reminderId ? { ...reminder, ...updates } : reminder
          ) 
        } : prev
      );
    }
  };

  // 删除提醒
  const deleteReminder = (profileId: string, reminderId: string) => {
    setProfiles(prev => 
      prev.map(profile => 
        profile.id === profileId 
          ? { ...profile, reminders: profile.reminders.filter(reminder => reminder.id !== reminderId) } 
          : profile
      )
    );
    
    if (currentProfile?.id === profileId) {
      setCurrentProfileState(prev => 
        prev ? { ...prev, reminders: prev.reminders.filter(reminder => reminder.id !== reminderId) } : prev
      );
    }
  };

  // 获取风险分析
  const getRiskAnalysis = (profileId: string) => {
    const profile = profiles.find(p => p.id === profileId);
    if (!profile) {
      return { level: 'low' as const, factors: [] };
    }

    const factors: string[] = [];
    let riskLevel: 'low' | 'medium' | 'high' = 'low';
    
    // 分析最近的测试记录
    const recentTests = [...profile.testRecords].sort((a, b) => 
      new Date(b.date).getTime() - new Date(a.date).getTime()
    );
    
    // 检查MMSE和MoCA测试结果
    const recentMmse = recentTests.find(test => test.type === 'mmse');
    const recentMoca = recentTests.find(test => test.type === 'moca');
    
    if (recentMmse) {
      const threshold = profile.education === 'primary' ? 17 :
                      profile.education === 'secondary' ? 20 : 24;
      if (recentMmse.score < threshold) {
        factors.push('MMSE测试显示可能存在认知障碍');
        riskLevel = 'high';
      }
    }
    
    if (recentMoca && recentMoca.score < 26) {
      factors.push('MoCA测试显示可能存在轻度认知障碍');
      riskLevel = riskLevel === 'high' ? 'high' : 'medium';
    }
    
    // 检查焦虑和抑郁
    const recentHama = recentTests.find(test => test.type === 'hama');
    const recentHamd = recentTests.find(test => test.type === 'hamd');
    
    if (recentHama) {
      if (recentHama.score >= 14) {
        factors.push('存在中度或以上焦虑症状');
        riskLevel = riskLevel === 'low' ? 'medium' : riskLevel;
      }
    }
    
    if (recentHamd) {
      if (recentHamd.score >= 17) {
        factors.push('存在中度或以上抑郁症状');
        riskLevel = riskLevel === 'low' ? 'medium' : riskLevel;
      }
    }
    
    // 检查年龄因素
    const age = new Date().getFullYear() - new Date(profile.birthDate).getFullYear();
    if (age >= 65) {
      factors.push('年龄因素（65岁及以上）');
      riskLevel = riskLevel === 'low' ? 'medium' : riskLevel;
    }
    
    return { level: riskLevel, factors };
  };

  const value = {
    currentProfile,
    profiles,
    createProfile,
    updateProfile,
    deleteProfile,
    setCurrentProfile,
    addTestRecord,
    addHealthInfo,
    addReminder,
    updateReminder,
    deleteHealthInfo,
    deleteReminder,
    getRiskAnalysis
  };

  return (
    <ProfileContext.Provider value={value}>
      {children}
    </ProfileContext.Provider>
  );
};

export const useProfile = () => {
  const context = useContext(ProfileContext);
  if (context === undefined) {
    throw new Error('useProfile must be used within a ProfileProvider');
  }
  return context;
};