import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { nanoid } from 'nanoid';
import { UserProfile } from './ProfileContext';

// 家庭成员类型
export interface FamilyMember {
  id: string;
  profileId: string;
  role: 'primary' | 'caregiver';
  permissions: {
    canView: boolean;
    canEdit: boolean;
    canManageReminders: boolean;
  };
}

// 家庭类型
export interface Family {
  id: string;
  name: string;
  members: FamilyMember[];
  sharedRecords: {
    id: string;
    profileId: string;
    testId: string;
    sharedDate: string;
    note?: string;
  }[];
  careNotes: {
    id: string;
    createdBy: string;
    date: string;
    content: string;
    forProfileId: string;
  }[];
}

interface FamilyContextType {
  families: Family[];
  currentFamily: Family | null;
  createFamily: (name: string, primaryMemberId: string) => void;
  updateFamily: (id: string, updates: Partial<Family>) => void;
  deleteFamily: (id: string) => void;
  setCurrentFamily: (id: string | null) => void;
  addFamilyMember: (familyId: string, profileId: string, role: 'primary' | 'caregiver', permissions: FamilyMember['permissions']) => void;
  updateFamilyMember: (familyId: string, memberId: string, updates: Partial<FamilyMember>) => void;
  removeFamilyMember: (familyId: string, memberId: string) => void;
  shareTestRecord: (familyId: string, profileId: string, testId: string, note?: string) => void;
  removeSharedRecord: (familyId: string, recordId: string) => void;
  addCareNote: (familyId: string, createdBy: string, forProfileId: string, content: string) => void;
  updateCareNote: (familyId: string, noteId: string, content: string) => void;
  deleteCareNote: (familyId: string, noteId: string) => void;
  getFamiliesForProfile: (profileId: string) => Family[];
  getProfilesInFamily: (familyId: string, profiles: UserProfile[]) => UserProfile[];
}

const FamilyContext = createContext<FamilyContextType | undefined>(undefined);

export const FamilyProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [families, setFamilies] = useState<Family[]>([]);
  const [currentFamily, setCurrentFamilyState] = useState<Family | null>(null);

  // 从本地存储加载数据
  useEffect(() => {
    const savedFamilies = localStorage.getItem('families');
    const currentFamilyId = localStorage.getItem('currentFamilyId');
    
    if (savedFamilies) {
      const parsedFamilies = JSON.parse(savedFamilies);
      setFamilies(parsedFamilies);
      
      if (currentFamilyId) {
        const family = parsedFamilies.find((f: Family) => f.id === currentFamilyId);
        if (family) {
          setCurrentFamilyState(family);
        }
      }
    }
  }, []);

  // 保存数据到本地存储
  useEffect(() => {
    if (families.length > 0) {
      localStorage.setItem('families', JSON.stringify(families));
    }
    
    if (currentFamily) {
      localStorage.setItem('currentFamilyId', currentFamily.id);
    }
  }, [families, currentFamily]);

  // 创建新家庭
  const createFamily = (name: string, primaryMemberId: string) => {
    const newFamily: Family = {
      id: nanoid(),
      name,
      members: [
        {
          id: nanoid(),
          profileId: primaryMemberId,
          role: 'primary',
          permissions: {
            canView: true,
            canEdit: true,
            canManageReminders: true
          }
        }
      ],
      sharedRecords: [],
      careNotes: []
    };
    
    setFamilies(prev => [...prev, newFamily]);
    setCurrentFamilyState(newFamily);
  };

  // 更新家庭
  const updateFamily = (id: string, updates: Partial<Family>) => {
    setFamilies(prev => 
      prev.map(family => 
        family.id === id ? { ...family, ...updates } : family
      )
    );
    
    if (currentFamily?.id === id) {
      setCurrentFamilyState(prev => prev ? { ...prev, ...updates } : prev);
    }
  };

  // 删除家庭
  const deleteFamily = (id: string) => {
    setFamilies(prev => prev.filter(family => family.id !== id));
    
    if (currentFamily?.id === id) {
      setCurrentFamilyState(null);
      localStorage.removeItem('currentFamilyId');
    }
  };

  // 设置当前家庭
  const setCurrentFamily = (id: string | null) => {
    if (id === null) {
      setCurrentFamilyState(null);
      localStorage.removeItem('currentFamilyId');
      return;
    }
    
    const family = families.find(f => f.id === id);
    if (family) {
      setCurrentFamilyState(family);
      localStorage.setItem('currentFamilyId', id);
    }
  };

  // 添加家庭成员
  const addFamilyMember = (
    familyId: string, 
    profileId: string, 
    role: 'primary' | 'caregiver', 
    permissions: FamilyMember['permissions']
  ) => {
    const newMember: FamilyMember = {
      id: nanoid(),
      profileId,
      role,
      permissions
    };
    
    setFamilies(prev => 
      prev.map(family => 
        family.id === familyId 
          ? { ...family, members: [...family.members, newMember] } 
          : family
      )
    );
    
    if (currentFamily?.id === familyId) {
      setCurrentFamilyState(prev => 
        prev ? { ...prev, members: [...prev.members, newMember] } : prev
      );
    }
  };

  // 更新家庭成员
  const updateFamilyMember = (familyId: string, memberId: string, updates: Partial<FamilyMember>) => {
    setFamilies(prev => 
      prev.map(family => 
        family.id === familyId 
          ? { 
              ...family, 
              members: family.members.map(member => 
                member.id === memberId ? { ...member, ...updates } : member
              ) 
            } 
          : family
      )
    );
    
    if (currentFamily?.id === familyId) {
      setCurrentFamilyState(prev => 
        prev ? { 
          ...prev, 
          members: prev.members.map(member => 
            member.id === memberId ? { ...member, ...updates } : member
          ) 
        } : prev
      );
    }
  };

  // 移除家庭成员
  const removeFamilyMember = (familyId: string, memberId: string) => {
    setFamilies(prev => 
      prev.map(family => 
        family.id === familyId 
          ? { ...family, members: family.members.filter(member => member.id !== memberId) } 
          : family
      )
    );
    
    if (currentFamily?.id === familyId) {
      setCurrentFamilyState(prev => 
        prev ? { ...prev, members: prev.members.filter(member => member.id !== memberId) } : prev
      );
    }
  };

  // 分享测试记录
  const shareTestRecord = (familyId: string, profileId: string, testId: string, note?: string) => {
    const sharedRecord = {
      id: nanoid(),
      profileId,
      testId,
      sharedDate: new Date().toISOString(),
      note
    };
    
    setFamilies(prev => 
      prev.map(family => 
        family.id === familyId 
          ? { ...family, sharedRecords: [...family.sharedRecords, sharedRecord] } 
          : family
      )
    );
    
    if (currentFamily?.id === familyId) {
      setCurrentFamilyState(prev => 
        prev ? { ...prev, sharedRecords: [...prev.sharedRecords, sharedRecord] } : prev
      );
    }
  };

  // 移除分享的记录
  const removeSharedRecord = (familyId: string, recordId: string) => {
    setFamilies(prev => 
      prev.map(family => 
        family.id === familyId 
          ? { ...family, sharedRecords: family.sharedRecords.filter(record => record.id !== recordId) } 
          : family
      )
    );
    
    if (currentFamily?.id === familyId) {
      setCurrentFamilyState(prev => 
        prev ? { ...prev, sharedRecords: prev.sharedRecords.filter(record => record.id !== recordId) } : prev
      );
    }
  };

  // 添加照护笔记
  const addCareNote = (familyId: string, createdBy: string, forProfileId: string, content: string) => {
    const careNote = {
      id: nanoid(),
      createdBy,
      forProfileId,
      date: new Date().toISOString(),
      content
    };
    
    setFamilies(prev => 
      prev.map(family => 
        family.id === familyId 
          ? { ...family, careNotes: [...family.careNotes, careNote] } 
          : family
      )
    );
    
    if (currentFamily?.id === familyId) {
      setCurrentFamilyState(prev => 
        prev ? { ...prev, careNotes: [...prev.careNotes, careNote] } : prev
      );
    }
  };

  // 更新照护笔记
  const updateCareNote = (familyId: string, noteId: string, content: string) => {
    setFamilies(prev => 
      prev.map(family => 
        family.id === familyId 
          ? { 
              ...family, 
              careNotes: family.careNotes.map(note => 
                note.id === noteId ? { ...note, content } : note
              ) 
            } 
          : family
      )
    );
    
    if (currentFamily?.id === familyId) {
      setCurrentFamilyState(prev => 
        prev ? { 
          ...prev, 
          careNotes: prev.careNotes.map(note => 
            note.id === noteId ? { ...note, content } : note
          ) 
        } : prev
      );
    }
  };

  // 删除照护笔记
  const deleteCareNote = (familyId: string, noteId: string) => {
    setFamilies(prev => 
      prev.map(family => 
        family.id === familyId 
          ? { ...family, careNotes: family.careNotes.filter(note => note.id !== noteId) } 
          : family
      )
    );
    
    if (currentFamily?.id === familyId) {
      setCurrentFamilyState(prev => 
        prev ? { ...prev, careNotes: prev.careNotes.filter(note => note.id !== noteId) } : prev
      );
    }
  };

  // 获取用户所在的所有家庭
  const getFamiliesForProfile = (profileId: string) => {
    return families.filter(family => 
      family.members.some(member => member.profileId === profileId)
    );
  };

  // 获取家庭中的所有用户档案
  const getProfilesInFamily = (familyId: string, profiles: UserProfile[]) => {
    const family = families.find(f => f.id === familyId);
    if (!family) return [];
    
    return profiles.filter(profile => 
      family.members.some(member => member.profileId === profile.id)
    );
  };

  const value = {
    families,
    currentFamily,
    createFamily,
    updateFamily,
    deleteFamily,
    setCurrentFamily,
    addFamilyMember,
    updateFamilyMember,
    removeFamilyMember,
    shareTestRecord,
    removeSharedRecord,
    addCareNote,
    updateCareNote,
    deleteCareNote,
    getFamiliesForProfile,
    getProfilesInFamily
  };

  return (
    <FamilyContext.Provider value={value}>
      {children}
    </FamilyContext.Provider>
  );
};

export const useFamily = () => {
  const context = useContext(FamilyContext);
  if (context === undefined) {
    throw new Error('useFamily must be used within a FamilyProvider');
  }
  return context;
};