import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { hamaQuestions } from '../data/hamaQuestions';
import { hamdQuestions } from '../data/hamdQuestions';
import { mmseQuestions } from '../data/mmseQuestions';
import { mocaQuestions } from '../data/mocaQuestions';

type AssessmentType = 'hama' | 'hamd' | 'mmse' | 'moca';

interface UserInfo {
  name: string;
  gender: 'male' | 'female' | 'other';
  birthDate: string;
  education: string;
  assessmentDate: string;
}

interface Answer {
  questionId: string;
  answerId: string | string[];
  value: number;
}

interface AssessmentContextType {
  currentAssessment: AssessmentType | null;
  setCurrentAssessment: (assessment: AssessmentType | null) => void;
  answers: Record<AssessmentType, Answer[]>;
  saveAnswer: (assessment: AssessmentType, answer: Answer) => void;
  resetAnswers: (assessment?: AssessmentType) => void;
  userInfo: UserInfo;
  updateUserInfo: (info: Partial<UserInfo>) => void;
  progress: Record<AssessmentType, number>;
  calculateScore: (assessment: AssessmentType) => number;
  interpretScore: (assessment: AssessmentType, score: number) => string;
}

const defaultUserInfo: UserInfo = {
  name: '',
  gender: 'male',
  birthDate: '',
  education: '',
  assessmentDate: new Date().toISOString().split('T')[0],
};

const AssessmentContext = createContext<AssessmentContextType | undefined>(undefined);

export const AssessmentProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [currentAssessment, setCurrentAssessment] = useState<AssessmentType | null>(null);
  const [userInfo, setUserInfo] = useState<UserInfo>(defaultUserInfo);
  const [answers, setAnswers] = useState<Record<AssessmentType, Answer[]>>({
    hama: [],
    hamd: [],
    mmse: [],
    moca: [],
  });
  const [progress, setProgress] = useState<Record<AssessmentType, number>>({
    hama: 0,
    hamd: 0,
    mmse: 0,
    moca: 0,
  });

  // Update progress when answers change
  useEffect(() => {
    const questionCounts = {
      hama: hamaQuestions.length,
      hamd: hamdQuestions.length,
      mmse: mmseQuestions().length, // Call mmseQuestions function to get the array
      moca: mocaQuestions.length,
    };

    const newProgress = {
      hama: Math.round((answers.hama.length / questionCounts.hama) * 100),
      hamd: Math.round((answers.hamd.length / questionCounts.hamd) * 100),
      mmse: Math.round((answers.mmse.length / questionCounts.mmse) * 100),
      moca: Math.round((answers.moca.length / questionCounts.moca) * 100),
    };

    setProgress(newProgress);
  }, [answers]);

  const saveAnswer = (assessment: AssessmentType, answer: Answer) => {
    setAnswers((prev) => {
      // Remove any existing answer for this question
      const filteredAnswers = prev[assessment].filter(
        (a) => a.questionId !== answer.questionId
      );
      
      return {
        ...prev,
        [assessment]: [...filteredAnswers, answer],
      };
    });
  };

  const resetAnswers = (assessment?: AssessmentType) => {
    if (assessment) {
      setAnswers((prev) => ({
        ...prev,
        [assessment]: [],
      }));
    } else {
      setAnswers({
        hama: [],
        hamd: [],
        mmse: [],
        moca: [],
      });
    }
  };

  const updateUserInfo = (info: Partial<UserInfo>) => {
    setUserInfo((prev) => ({ ...prev, ...info }));
  };

  const calculateScore = (assessment: AssessmentType): number => {
    return answers[assessment].reduce((total, answer) => total + answer.value, 0);
  };

  const interpretScore = (assessment: AssessmentType, score: number): string => {
    switch (assessment) {
      case 'hama':
        if (score < 7) return '无明显焦虑';
        if (score < 14) return '可能存在轻度焦虑';
        if (score < 21) return '存在中度焦虑';
        if (score < 30) return '存在重度焦虑';
        return '存在极重度焦虑';
      
      case 'hamd':
        if (score < 8) return '无抑郁症状';
        if (score < 17) return '可能存在轻度抑郁';
        if (score < 24) return '存在中度抑郁';
        return '存在重度抑郁';
      
      case 'mmse':
        const educationFactor = userInfo.education === 'primary' ? 17 :
                              userInfo.education === 'secondary' ? 20 : 24;
        if (score < educationFactor) return '可能存在认知障碍';
        return '认知功能正常';
      
      case 'moca':
        if (score < 26) return '可能存在轻度认知障碍';
        return '认知功能正常';
      
      default:
        return '无法解释结果';
    }
  };

  const value: AssessmentContextType = {
    currentAssessment,
    setCurrentAssessment,
    answers,
    saveAnswer,
    resetAnswers,
    userInfo,
    updateUserInfo,
    progress,
    calculateScore,
    interpretScore,
  };

  return (
    <AssessmentContext.Provider value={value}>
      {children}
    </AssessmentContext.Provider>
  );
};

export const useAssessment = () => {
  const context = useContext(AssessmentContext);
  if (context === undefined) {
    throw new Error('useAssessment must be used within an AssessmentProvider');
  }
  return context;
};