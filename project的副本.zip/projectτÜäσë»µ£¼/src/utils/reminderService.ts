import { Reminder } from '../context/ProfileContext';

// 检查提醒是否应该触发
export const shouldTriggerReminder = (reminder: Reminder): boolean => {
  if (reminder.completed) return false;
  
  const now = new Date();
  const reminderDate = new Date(`${reminder.date}T${reminder.time}`);
  
  // 如果提醒时间已过，但在过去30分钟内，仍然触发
  if (reminderDate < now) {
    const diffMs = now.getTime() - reminderDate.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    return diffMins <= 30;
  }
  
  return false;
};

// 获取即将到来的提醒
export const getUpcomingReminders = (reminders: Reminder[]): Reminder[] => {
  const now = new Date();
  
  return reminders
    .filter(reminder => !reminder.completed)
    .filter(reminder => {
      const reminderDate = new Date(`${reminder.date}T${reminder.time}`);
      return reminderDate > now;
    })
    .sort((a, b) => {
      const dateA = new Date(`${a.date}T${a.time}`);
      const dateB = new Date(`${b.date}T${b.time}`);
      return dateA.getTime() - dateB.getTime();
    });
};

// 格式化提醒时间
export const formatReminderTime = (date: string, time: string): string => {
  const reminderDate = new Date(`${date}T${time}`);
  const now = new Date();
  
  // 如果是今天
  if (
    reminderDate.getDate() === now.getDate() &&
    reminderDate.getMonth() === now.getMonth() &&
    reminderDate.getFullYear() === now.getFullYear()
  ) {
    return `今天 ${time}`;
  }
  
  // 如果是明天
  const tomorrow = new Date(now);
  tomorrow.setDate(tomorrow.getDate() + 1);
  if (
    reminderDate.getDate() === tomorrow.getDate() &&
    reminderDate.getMonth() === tomorrow.getMonth() &&
    reminderDate.getFullYear() === tomorrow.getFullYear()
  ) {
    return `明天 ${time}`;
  }
  
  // 其他日期
  return `${new Date(date).toLocaleDateString()} ${time}`;
};

// 生成提醒通知标题
export const getReminderNotificationTitle = (reminder: Reminder): string => {
  switch (reminder.type) {
    case 'test':
      return '测试提醒';
    case 'medication':
      return '用药提醒';
    case 'appointment':
      return '就诊提醒';
    case 'activity':
      return '活动提醒';
    default:
      return '提醒';
  }
};

// 生成提醒通知内容
export const getReminderNotificationBody = (reminder: Reminder): string => {
  const timeStr = formatReminderTime(reminder.date, reminder.time);
  return `${reminder.title} - ${timeStr}${reminder.description ? `\n${reminder.description}` : ''}`;
};