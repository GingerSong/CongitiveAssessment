import { useEffect, useState } from 'react';

interface NotificationOptions {
  title: string;
  body: string;
  icon?: string;
  tag?: string;
  onClick?: () => void;
}

export const useNotification = () => {
  const [permission, setPermission] = useState<NotificationPermission | null>(null);

  useEffect(() => {
    if ('Notification' in window) {
      setPermission(Notification.permission);
    }
  }, []);

  const requestPermission = async (): Promise<boolean> => {
    if (!('Notification' in window)) {
      console.warn('This browser does not support notifications');
      return false;
    }

    if (Notification.permission === 'granted') {
      setPermission('granted');
      return true;
    }

    if (Notification.permission !== 'denied') {
      const result = await Notification.requestPermission();
      setPermission(result);
      return result === 'granted';
    }

    return false;
  };

  const showNotification = async (options: NotificationOptions): Promise<boolean> => {
    if (!('Notification' in window)) {
      console.warn('This browser does not support notifications');
      return false;
    }

    if (Notification.permission !== 'granted') {
      const granted = await requestPermission();
      if (!granted) return false;
    }

    try {
      const notification = new Notification(options.title, {
        body: options.body,
        icon: options.icon,
        tag: options.tag
      });

      if (options.onClick) {
        notification.onclick = options.onClick;
      }

      return true;
    } catch (error) {
      console.error('Error showing notification:', error);
      return false;
    }
  };

  const scheduleNotification = (options: NotificationOptions, delay: number): number => {
    return window.setTimeout(() => {
      showNotification(options);
    }, delay);
  };

  return {
    permission,
    requestPermission,
    showNotification,
    scheduleNotification
  };
};

export default useNotification;