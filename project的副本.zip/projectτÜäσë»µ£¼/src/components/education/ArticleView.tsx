import React from 'react';
import { ArrowLeft } from 'lucide-react';
import { EducationArticle, ArticleSection } from '../../data/educationContent';

interface ArticleViewProps {
  article: EducationArticle;
  onBack: () => void;
}

const ArticleView: React.FC<ArticleViewProps> = ({ article, onBack }) => {
  const renderSection = (section: ArticleSection, index: number) => {
    const sectionKey = `section-${index}`;
    
    return (
      <div key={sectionKey} className="mb-8">
        <h3 className="text-xl font-semibold text-gray-800 mb-3">{section.title}</h3>
        
        {section.imageUrl && (
          <div className="mb-4">
            <img 
              src={section.imageUrl} 
              alt={section.title} 
              className="w-full h-auto max-h-60 object-cover rounded-lg"
            />
          </div>
        )}
        
        {section.type === 'text' && (
          <p className="text-gray-700">{section.content}</p>
        )}
        
        {section.type === 'list' && section.items && (
          <ul className="space-y-2 text-gray-700">
            {section.items.map((item, i) => (
              <li key={`item-${i}`} className="flex items-start">
                <span className="text-blue-500 mr-2">•</span>
                <span>{item}</span>
              </li>
            ))}
          </ul>
        )}
        
        {section.type === 'steps' && section.items && (
          <ol className="space-y-3 text-gray-700">
            {section.items.map((item, i) => (
              <li key={`step-${i}`} className="flex items-start">
                <span className="flex-shrink-0 flex items-center justify-center w-6 h-6 rounded-full bg-blue-100 text-blue-600 font-medium mr-3">
                  {i + 1}
                </span>
                <span>{item}</span>
              </li>
            ))}
          </ol>
        )}
        
        {section.type === 'tips' && section.items && (
          <div className="bg-green-50 border border-green-200 rounded-lg p-4">
            <ul className="space-y-2 text-gray-700">
              {section.items.map((item, i) => (
                <li key={`tip-${i}`} className="flex items-start">
                  <span className="text-green-500 mr-2">✓</span>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>
        )}
        
        {section.type === 'warning' && (
          <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
            {section.content && <p className="text-gray-700 mb-2">{section.content}</p>}
            {section.items && (
              <ul className="space-y-2 text-gray-700">
                {section.items.map((item, i) => (
                  <li key={`warning-${i}`} className="flex items-start">
                    <span className="text-amber-500 mr-2">⚠</span>
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            )}
          </div>
        )}
        
        {section.type === 'highlight' && (
          <div className="bg-blue-50 border-l-4 border-blue-500 p-4 rounded-r-lg">
            <p className="text-gray-700 italic">{section.content}</p>
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex items-center mb-6">
        <button 
          onClick={onBack}
          className="mr-3 p-1 rounded-full hover:bg-gray-100"
          aria-label="返回"
          title="返回"
        >
          <ArrowLeft className="h-5 w-5 text-gray-600" />
        </button>
        <h2 className="text-2xl font-bold text-gray-800">{article.title}</h2>
      </div>
      
      {article.imageUrl && (
        <div className="mb-6">
          <img 
            src={article.imageUrl} 
            alt={article.title} 
            className="w-full h-auto max-h-80 object-cover rounded-lg"
          />
        </div>
      )}
      
      <p className="text-lg text-gray-600 mb-8">{article.summary}</p>
      
      <div className="space-y-8">
        {article.sections.map(renderSection)}
      </div>
    </div>
  );
};

export default ArticleView;