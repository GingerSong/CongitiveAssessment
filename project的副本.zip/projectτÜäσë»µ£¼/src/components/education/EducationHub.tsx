import React, { useState } from 'react';
import { Book, Activity, Shield, Stethoscope } from 'lucide-react';
import { educationArticles, EducationArticle } from '../../data/educationContent';
import ArticleView from './ArticleView';

interface EducationHubProps {
  onBack?: () => void;
}

const EducationHub: React.FC<EducationHubProps> = () => {
  const [activeCategory, setActiveCategory] = useState<'basics' | 'activities' | 'prevention' | 'professional'>('basics');
  const [selectedArticle, setSelectedArticle] = useState<EducationArticle | null>(null);
  
  const categories = [
    { id: 'basics', name: '认知健康基础知识', icon: <Book className="h-5 w-5" /> },
    { id: 'activities', name: '干预活动建议', icon: <Activity className="h-5 w-5" /> },
    { id: 'prevention', name: '预防策略指南', icon: <Shield className="h-5 w-5" /> },
    { id: 'professional', name: '专业帮助指导', icon: <Stethoscope className="h-5 w-5" /> },
  ];
  
  const filteredArticles = educationArticles.filter(article => article.category === activeCategory);
  
  if (selectedArticle) {
    return (
      <ArticleView 
        article={selectedArticle} 
        onBack={() => setSelectedArticle(null)} 
      />
    );
  }
  
  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-2xl font-bold text-gray-800 mb-6">认知健康科普与指导</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        {categories.map(category => (
          <button
            key={category.id}
            onClick={() => setActiveCategory(category.id as any)}
            className={`
              p-4 rounded-lg flex flex-col items-center justify-center text-center transition-colors
              ${activeCategory === category.id 
                ? 'bg-blue-100 text-blue-700 border-2 border-blue-300' 
                : 'bg-gray-50 text-gray-700 border border-gray-200 hover:bg-gray-100'}
            `}
          >
            <div className="mb-2">
              {category.icon}
            </div>
            <span className="font-medium">{category.name}</span>
          </button>
        ))}
      </div>
      
      <div className="space-y-4">
        {filteredArticles.map(article => (
          <div 
            key={article.id}
            onClick={() => setSelectedArticle(article)}
            className="p-4 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer transition-colors"
          >
            <h3 className="text-lg font-medium text-gray-800">{article.title}</h3>
            <p className="text-gray-600 mt-1 line-clamp-2">
              {article.summary}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default EducationHub;