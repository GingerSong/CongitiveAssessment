import React, { ReactNode } from 'react';
import Header from './Header';

interface LayoutProps {
  children: ReactNode;
  currentScreen?: 'intro' | 'assessment' | 'results' | 'profile' | 'family' | 'education';
  onNavigate?: (screen: 'intro' | 'assessment' | 'results' | 'profile' | 'family' | 'education') => void;
}

const Layout: React.FC<LayoutProps> = ({ children, currentScreen, onNavigate }) => {
  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      {currentScreen && onNavigate && (
        <Header currentScreen={currentScreen} onNavigate={onNavigate} />
      )}
      <main className="max-w-4xl mx-auto px-4 py-8">
        {children}
      </main>
      <footer className="bg-white p-4 text-center text-gray-500 text-sm shadow-inner">
        <p>© {new Date().getFullYear()} 认知障碍自评工具 | 本测试仅供参考，不能替代专业医疗诊断</p>
      </footer>
    </div>
  );
};

export default Layout;