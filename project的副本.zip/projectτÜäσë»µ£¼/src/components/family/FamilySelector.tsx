import React, { useState } from 'react';
import { useFamily } from '../../context/FamilyContext';
import { useProfile } from '../../context/ProfileContext';
import { Users, UserPlus, Edit, Trash2 } from 'lucide-react';

interface FamilySelectorProps {
  onCreateFamily?: () => void;
}

const FamilySelector: React.FC<FamilySelectorProps> = ({ onCreateFamily }) => {
  const { families, currentFamily, setCurrentFamily, deleteFamily } = useFamily();
  const { currentProfile } = useProfile();
  
  if (!currentProfile) {
    return (
      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="text-center py-8">
          <Users className="h-12 w-12 text-blue-500 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-800 mb-2">请先选择个人档案</h3>
          <p className="text-gray-600">您需要先选择或创建一个个人档案，才能使用家庭协作功能</p>
        </div>
      </div>
    );
  }
  
  // 获取当前用户所在的家庭
  const userFamilies = families.filter(family => 
    family.members.some(member => member.profileId === currentProfile.id)
  );
  
  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-gray-800">家庭账户</h2>
        <button
          onClick={onCreateFamily}
          className="flex items-center px-3 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
        >
          <UserPlus className="h-4 w-4 mr-1" />
          创建家庭账户
        </button>
      </div>
      
      {userFamilies.length > 0 ? (
        <div className="space-y-4">
          {userFamilies.map(family => {
            const userRole = family.members.find(m => m.profileId === currentProfile.id)?.role;
            const isPrimary = userRole === 'primary';
            
            return (
              <div 
                key={family.id} 
                className={`border rounded-lg p-4 flex justify-between items-center cursor-pointer hover:bg-gray-50 transition-colors ${
                  currentFamily?.id === family.id ? 'border-blue-500 bg-blue-50' : ''
                }`}
                onClick={() => setCurrentFamily(family.id)}
              >
                <div className="flex items-center">
                  <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center mr-3">
                    <Users className="h-5 w-5 text-blue-600" />
                  </div>
                  <div>
                    <div className="font-medium text-gray-800">{family.name}</div>
                    <div className="text-sm text-gray-500">
                      {family.members.length} 位成员 | 您是{isPrimary ? '主要账户' : '照护者'}
                    </div>
                  </div>
                </div>
                
                {isPrimary && (
                  <div className="flex space-x-2">
                    <button 
                      className="p-1 text-gray-400 hover:text-gray-600"
                      onClick={(e) => {
                        e.stopPropagation();
                        // 编辑功能可以在这里实现
                      }}
                    >
                      <Edit className="h-4 w-4" />
                    </button>
                    <button 
                      className="p-1 text-gray-400 hover:text-red-600"
                      onClick={(e) => {
                        e.stopPropagation();
                        if (window.confirm('确定要删除此家庭账户吗？')) {
                          deleteFamily(family.id);
                        }
                      }}
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      ) : (
        <div className="text-center py-8">
          <Users className="h-12 w-12 text-blue-500 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-800 mb-2">暂无家庭账户</h3>
          <p className="text-gray-600 mb-6">创建一个家庭账户，邀请家人加入，共同管理健康状况</p>
          <button
            onClick={onCreateFamily}
            className="px-4 py-2 bg-blue-600 text-white font-medium rounded-md hover:bg-blue-700 transition-colors"
          >
            创建家庭账户
          </button>
        </div>
      )}
    </div>
  );
};

export default FamilySelector;