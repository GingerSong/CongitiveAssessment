import React, { useState } from 'react';
import { useFamily } from '../../context/FamilyContext';
import { useProfile } from '../../context/ProfileContext';

interface FamilyFormProps {
  onComplete?: () => void;
}

const FamilyForm: React.FC<FamilyFormProps> = ({ onComplete }) => {
  const { createFamily } = useFamily();
  const { currentProfile } = useProfile();
  const [familyName, setFamilyName] = useState('');
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!currentProfile) {
      alert('请先选择一个个人档案');
      return;
    }
    
    createFamily(familyName, currentProfile.id);
    
    if (onComplete) {
      onComplete();
    }
  };
  
  if (!currentProfile) {
    return (
      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="text-center py-8">
          <h3 className="text-lg font-medium text-gray-800 mb-2">请先选择个人档案</h3>
          <p className="text-gray-600">您需要先选择或创建一个个人档案，才能创建家庭账户</p>
        </div>
      </div>
    );
  }
  
  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-2xl font-bold text-gray-800 mb-6">创建家庭账户</h2>
      
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="familyName" className="block text-sm font-medium text-gray-700 mb-1">家庭名称</label>
          <input
            type="text"
            id="familyName"
            value={familyName}
            onChange={(e) => setFamilyName(e.target.value)}
            required
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring focus:ring-blue-300 focus:outline-none transition"
            placeholder="例如：张家"
          />
        </div>
        
        <div className="bg-gray-50 p-4 rounded-md mb-4">
          <h3 className="font-medium text-gray-700 mb-2">主要账户信息</h3>
          <div className="flex items-center">
            <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center mr-3">
              <span className="text-blue-600 font-medium">{currentProfile.name.charAt(0)}</span>
            </div>
            <div>
              <div className="font-medium text-gray-800">{currentProfile.name}</div>
              <div className="text-sm text-gray-500">
                {currentProfile.gender === 'male' ? '男' : currentProfile.gender === 'female' ? '女' : '其他'} | 
                {new Date(currentProfile.birthDate).toLocaleDateString()}
              </div>
            </div>
          </div>
          <p className="text-sm text-gray-500 mt-3">
            您将成为此家庭账户的主要账户，可以邀请其他成员加入并管理家庭账户。
          </p>
        </div>
        
        <div className="pt-4">
          <button
            type="submit"
            className="w-full py-3 bg-blue-600 text-white font-semibold rounded-md hover:bg-blue-700 transition-colors focus:ring focus:ring-blue-300 focus:outline-none"
          >
            创建家庭账户
          </button>
        </div>
      </form>
    </div>
  );
};

export default FamilyForm;