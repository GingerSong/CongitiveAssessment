import React, { useState } from 'react';
import { useFamily } from '../../context/FamilyContext';
import { useProfile } from '../../context/ProfileContext';
import { UserPlus, Users, MessageSquare, Share2, Calendar, ArrowLeft, ClipboardList } from 'lucide-react';
import FamilySelector from './FamilySelector';
import FamilyForm from './FamilyForm';

interface FamilyDashboardProps {
  onBack?: () => void;
}

const FamilyDashboard: React.FC<FamilyDashboardProps> = ({ onBack }) => {
  const { currentFamily, getFamiliesForProfile, getProfilesInFamily } = useFamily();
  const { currentProfile, profiles } = useProfile();
  const [activeTab, setActiveTab] = useState<'overview' | 'members' | 'shared' | 'care'>('overview');
  const [showCreateForm, setShowCreateForm] = useState(false);
  
  if (showCreateForm) {
    return <FamilyForm onComplete={() => setShowCreateForm(false)} />;
  }
  
  if (!currentFamily) {
    return <FamilySelector onCreateFamily={() => setShowCreateForm(true)} />;
  }

  const familyProfiles = getProfilesInFamily(currentFamily.id, profiles);
  const userRole = currentFamily.members.find(member => member.profileId === currentProfile?.id)?.role;
  const isPrimary = userRole === 'primary';
  
  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex justify-between items-center mb-6">
        <div className="flex items-center">
          {onBack && (
            <button 
              onClick={onBack}
              className="mr-3 p-1 rounded-full hover:bg-gray-100"
              aria-label="返回"
              title="返回个人档案"
            >
              <ArrowLeft className="h-5 w-5 text-gray-600" />
            </button>
          )}
          <h2 className="text-2xl font-bold text-gray-800">家庭协作: {currentFamily.name}</h2>
        </div>
        <div className="flex items-center">
          <div className="text-sm text-gray-500 mr-4">
            {isPrimary ? '主要账户' : '照护者'}
          </div>
          <button 
            onClick={() => onBack && onBack()}
            className="flex items-center px-3 py-1 bg-gray-100 text-gray-700 rounded-md hover:bg-gray-200 transition-colors mr-2"
            aria-label="个人档案"
            title="返回个人档案"
          >
            <Users className="h-4 w-4 mr-1" />
            个人档案
          </button>
          <button 
            onClick={() => {
              // 直接导航到测试评估
              if (window.location.hash) {
                window.location.hash = '#assessment';
              } else {
                // 如果没有使用hash路由，可以通过事件或其他方式通知App组件
                const event = new CustomEvent('navigateToAssessment');
                window.dispatchEvent(event);
              }
            }}
            className="flex items-center px-3 py-1 bg-blue-100 text-blue-700 rounded-md hover:bg-blue-200 transition-colors"
            aria-label="测试评估"
            title="前往测试评估"
          >
            <ClipboardList className="h-4 w-4 mr-1" />
            测试评估
          </button>
        </div>
      </div>
      
      <div className="mb-6">
        <div className="flex space-x-2 mb-4">
          <button
            onClick={() => setActiveTab('overview')}
            className={`px-4 py-2 rounded-md ${
              activeTab === 'overview' 
                ? 'bg-blue-600 text-white' 
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            总览
          </button>
          <button
            onClick={() => setActiveTab('members')}
            className={`px-4 py-2 rounded-md ${
              activeTab === 'members' 
                ? 'bg-blue-600 text-white' 
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            成员管理
          </button>
          <button
            onClick={() => setActiveTab('shared')}
            className={`px-4 py-2 rounded-md ${
              activeTab === 'shared' 
                ? 'bg-blue-600 text-white' 
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            共享记录
          </button>
          <button
            onClick={() => setActiveTab('care')}
            className={`px-4 py-2 rounded-md ${
              activeTab === 'care' 
                ? 'bg-blue-600 text-white' 
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            照护笔记
          </button>
        </div>
      </div>
      
      {activeTab === 'overview' && (
        <div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div className="border rounded-lg p-4">
              <h3 className="text-lg font-medium text-gray-800 mb-3">家庭成员</h3>
              <div className="space-y-3">
                {familyProfiles.map(profile => {
                  const member = currentFamily.members.find(m => m.profileId === profile.id);
                  return (
                    <div key={profile.id} className="flex items-center justify-between">
                      <div className="flex items-center">
                        <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center mr-3">
                          <span className="text-blue-600 font-medium">{profile.name.charAt(0)}</span>
                        </div>
                        <div>
                          <div className="font-medium text-gray-800">{profile.name}</div>
                          <div className="text-xs text-gray-500">
                            {member?.role === 'primary' ? '主要账户' : '照护者'}
                          </div>
                        </div>
                      </div>
                      <div className="text-sm text-gray-500">
                        {new Date(profile.birthDate).getFullYear()}年生
                      </div>
                    </div>
                  );
                })}
              </div>
              {isPrimary && (
                <button className="mt-4 flex items-center text-sm text-blue-600 hover:text-blue-800">
                  <UserPlus className="h-4 w-4 mr-1" />
                  邀请家庭成员
                </button>
              )}
            </div>
            
            <div className="border rounded-lg p-4">
              <h3 className="text-lg font-medium text-gray-800 mb-3">最近共享记录</h3>
              {currentFamily.sharedRecords.length > 0 ? (
                <div className="space-y-3">
                  {[...currentFamily.sharedRecords]
                    .sort((a, b) => new Date(b.sharedDate).getTime() - new Date(a.sharedDate).getTime())
                    .slice(0, 3)
                    .map(record => {
                      const profile = profiles.find(p => p.id === record.profileId);
                      return (
                        <div key={record.id} className="flex items-start">
                          <div className="p-2 bg-blue-100 rounded-md mr-3">
                            <Share2 className="h-4 w-4 text-blue-600" />
                          </div>
                          <div>
                            <div className="font-medium text-gray-800">
                              {profile?.name} 分享了测试结果
                            </div>
                            <div className="text-xs text-gray-500">
                              {new Date(record.sharedDate).toLocaleDateString()}
                            </div>
                            {record.note && (
                              <div className="text-sm text-gray-600 mt-1">{record.note}</div>
                            )}
                          </div>
                        </div>
                      );
                    })}
                </div>
              ) : (
                <p className="text-gray-500">暂无共享记录</p>
              )}
            </div>
          </div>
          
          <div className="border rounded-lg p-4">
            <h3 className="text-lg font-medium text-gray-800 mb-3">照护建议</h3>
            <div className="space-y-4">
              <div className="p-4 bg-blue-50 rounded-lg">
                <h4 className="font-medium text-blue-800 mb-2">认知活动建议</h4>
                <p className="text-gray-700">定期进行认知训练活动有助于维持和提高认知功能。建议每天安排15-30分钟的认知训练，如阅读、拼图、记忆游戏等。</p>
              </div>
              
              <div className="p-4 bg-green-50 rounded-lg">
                <h4 className="font-medium text-green-800 mb-2">社交互动建议</h4>
                <p className="text-gray-700">保持良好的社交活动对认知健康非常重要。鼓励家人参加社区活动、与朋友聚会或参加兴趣小组。</p>
              </div>
              
              <div className="p-4 bg-amber-50 rounded-lg">
                <h4 className="font-medium text-amber-800 mb-2">定期评估提醒</h4>
                <p className="text-gray-700">建议每3-6个月进行一次认知功能评估，以便及时发现潜在问题并采取干预措施。</p>
                <button className="mt-2 flex items-center text-sm text-amber-700 hover:text-amber-900">
                  <Calendar className="h-4 w-4 mr-1" />
                  设置定期评估提醒
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
      
      {activeTab === 'members' && (
        <div>
          <h3 className="text-lg font-medium text-gray-800 mb-4">成员管理</h3>
          <div className="space-y-4">
            {familyProfiles.map(profile => {
              const member = currentFamily.members.find(m => m.profileId === profile.id);
              return (
                <div key={profile.id} className="border rounded-lg p-4">
                  <div className="flex justify-between items-start">
                    <div className="flex items-center">
                      <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center mr-4">
                        <span className="text-blue-600 font-medium text-lg">{profile.name.charAt(0)}</span>
                      </div>
                      <div>
                        <div className="font-medium text-gray-800">{profile.name}</div>
                        <div className="text-sm text-gray-500">
                          {member?.role === 'primary' ? '主要账户' : '照护者'} | 
                          {profile.gender === 'male' ? ' 男' : profile.gender === 'female' ? ' 女' : ' 其他'} | 
                          {new Date(profile.birthDate).getFullYear()}年生
                        </div>
                      </div>
                    </div>
                    {isPrimary && member?.role !== 'primary' && (
                      <button className="text-sm text-red-600 hover:text-red-800">
                        移除
                      </button>
                    )}
                  </div>
                  
                  {isPrimary && member?.role !== 'primary' && (
                    <div className="mt-4 border-t pt-4">
                      <h4 className="font-medium text-gray-700 mb-2">权限设置</h4>
                      <div className="space-y-2">
                        <div className="flex items-center">
                          <input 
                            type="checkbox" 
                            id={`view-${profile.id}`} 
                            checked={member?.permissions.canView} 
                            className="mr-2"
                          />
                          <label htmlFor={`view-${profile.id}`} className="text-gray-700">查看测试结果</label>
                        </div>
                        <div className="flex items-center">
                          <input 
                            type="checkbox" 
                            id={`edit-${profile.id}`} 
                            checked={member?.permissions.canEdit} 
                            className="mr-2"
                          />
                          <label htmlFor={`edit-${profile.id}`} className="text-gray-700">编辑个人信息</label>
                        </div>
                        <div className="flex items-center">
                          <input 
                            type="checkbox" 
                            id={`reminders-${profile.id}`} 
                            checked={member?.permissions.canManageReminders} 
                            className="mr-2"
                          />
                          <label htmlFor={`reminders-${profile.id}`} className="text-gray-700">管理提醒</label>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
            
            {isPrimary && (
              <button className="w-full py-3 flex items-center justify-center bg-blue-100 text-blue-700 rounded-md hover:bg-blue-200 transition-colors">
                <UserPlus className="h-5 w-5 mr-2" />
                邀请家庭成员
              </button>
            )}
          </div>
        </div>
      )}
      
      {activeTab === 'shared' && (
        <div>
          <h3 className="text-lg font-medium text-gray-800 mb-4">共享记录</h3>
          {currentFamily.sharedRecords.length > 0 ? (
            <div className="space-y-4">
              {[...currentFamily.sharedRecords]
                .sort((a, b) => new Date(b.sharedDate).getTime() - new Date(a.sharedDate).getTime())
                .map(record => {
                  const profile = profiles.find(p => p.id === record.profileId);
                  const testRecord = profile?.testRecords.find(t => t.id === record.testId);
                  
                  if (!testRecord) return null;
                  
                  return (
                    <div key={record.id} className="border rounded-lg p-4">
                      <div className="flex justify-between items-start">
                        <div>
                          <div className="font-medium text-gray-800">
                            {profile?.name} 的{' '}
                            {testRecord.type === 'hama' ? '汉密尔顿焦虑量表' : 
                             testRecord.type === 'hamd' ? '汉密尔顿抑郁量表' : 
                             testRecord.type === 'mmse' ? '简易精神状态检查' : 
                             '蒙特利尔认知评估'} 测试结果
                          </div>
                          <div className="text-sm text-gray-500 mt-1">
                            测试日期: {new Date(testRecord.date).toLocaleDateString()} | 
                            分享日期: {new Date(record.sharedDate).toLocaleDateString()}
                          </div>
                        </div>
                        <div className={`
                          px-3 py-1 rounded-full text-sm font-medium
                          ${testRecord.type === 'hama' ? 'bg-blue-100 text-blue-800' : 
                            testRecord.type === 'hamd' ? 'bg-purple-100 text-purple-800' : 
                            testRecord.type === 'mmse' ? 'bg-green-100 text-green-800' : 
                            'bg-amber-100 text-amber-800'}
                        `}>
                          分数: {testRecord.score}
                        </div>
                      </div>
                      
                      <div className="mt-3">
                        <div className="font-medium text-gray-700">结果解释:</div>
                        <p className="text-gray-700">{testRecord.interpretation}</p>
                      </div>
                      
                      {record.note && (
                        <div className="mt-3 p-3 bg-gray-50 rounded-md">
                          <div className="font-medium text-gray-700">分享备注:</div>
                          <p className="text-gray-700">{record.note}</p>
                        </div>
                      )}
                    </div>
                  );
                })}
            </div>
          ) : (
            <div className="text-center py-8">
              <Share2 className="h-12 w-12 text-blue-500 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-800 mb-2">暂无共享记录</h3>
              <p className="text-gray-600 mb-6">分享测试结果给家人，共同关注健康状况</p>
              <button className="px-4 py-2 bg-blue-600 text-white font-medium rounded-md hover:bg-blue-700 transition-colors">
                分享测试结果
              </button>
            </div>
          )}
        </div>
      )}
      
      {activeTab === 'care' && (
        <div>
          <h3 className="text-lg font-medium text-gray-800 mb-4">照护笔记</h3>
          <div className="mb-6">
            <textarea 
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring focus:ring-blue-300 focus:outline-none transition"
              rows={3}
              placeholder="添加新的照护笔记..."
            ></textarea>
            <div className="flex justify-between items-center mt-2">
              <div className="text-sm text-gray-500">
                为家人添加照护笔记，记录观察和建议
              </div>
              <button className="px-4 py-2 bg-blue-600 text-white font-medium rounded-md hover:bg-blue-700 transition-colors">
                添加笔记
              </button>
            </div>
          </div>
          
          {currentFamily.careNotes.length > 0 ? (
            <div className="space-y-4">
              {[...currentFamily.careNotes]
                .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                .map(note => {
                  const author = profiles.find(p => p.id === note.createdBy);
                  const forProfile = profiles.find(p => p.id === note.forProfileId);
                  
                  return (
                    <div key={note.id} className="border rounded-lg p-4">
                      <div className="flex justify-between items-start">
                        <div className="flex items-start">
                          <div className="p-2 bg-blue-100 rounded-md mr-3">
                            <MessageSquare className="h-4 w-4 text-blue-600" />
                          </div>
                          <div>
                            <div className="font-medium text-gray-800">
                              {author?.name} 关于 {forProfile?.name} 的笔记
                            </div>
                            <div className="text-xs text-gray-500 mt-1">
                              {new Date(note.date).toLocaleDateString()}
                            </div>
                          </div>
                        </div>
                        {note.createdBy === currentProfile?.id && (
                          <button className="text-sm text-red-600 hover:text-red-800">
                            删除
                          </button>
                        )}
                      </div>
                      <p className="text-gray-700 mt-3">{note.content}</p>
                    </div>
                  );
                })}
            </div>
          ) : (
            <div className="text-center py-8">
              <MessageSquare className="h-12 w-12 text-blue-500 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-800 mb-2">暂无照护笔记</h3>
              <p className="text-gray-600">添加照护笔记，记录观察和建议，帮助家人更好地照顾</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default FamilyDashboard;