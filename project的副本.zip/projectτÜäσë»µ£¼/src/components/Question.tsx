import React, { useState, useEffect, useRef } from 'react';
import { ArrowLeft, ArrowRight, Check } from 'lucide-react';
import { useAssessment } from '../context/AssessmentContext';
import { QuestionData, Option, ConnectionNode } from '../types/question';

interface QuestionProps {
  question: QuestionData;
  assessmentType: string;
  onNext: () => void;
  onPrev: () => void;
  isFirst: boolean;
  isLast: boolean;
}

const Question: React.FC<QuestionProps> = ({
  question,
  assessmentType,
  onNext,
  onPrev,
  isFirst,
  isLast,
}) => {
  const { answers, saveAnswer } = useAssessment();
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [selectedOptions, setSelectedOptions] = useState<string[]>([]);
  const [isMemoryPhase, setIsMemoryPhase] = useState(question.type === 'memory');
  const [showMemoryItems, setShowMemoryItems] = useState(true);
  
  // 序列显示相关状态
  const [isSequenceRunning, setIsSequenceRunning] = useState(false);
  const [currentSequenceIndex, setCurrentSequenceIndex] = useState(-1);
  const [sequenceComplete, setSequenceComplete] = useState(false);
  const [sequenceOptions, setSequenceOptions] = useState<Option[]>([]);

  // 连接游戏相关状态
  const [connections, setConnections] = useState<string[]>([]);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [connectionResult, setConnectionResult] = useState<boolean | null>(null);

  // 添加动态选项状态
  const [options, setOptions] = useState<Option[]>(question.options); 

  useEffect(() => {
    if (!assessmentType) return;
    
    // 处理动态选项
    if ('dynamicOptions' in question && 'getDynamicOptions' in question) {
      const getDynamicOptions = question.getDynamicOptions as () => Option[];
      setOptions(getDynamicOptions());
    } else {
      setOptions(question.options);
    }
      
    // 修复 assessmentType 类型错误和参数 a 的类型
    const existingAnswer = answers[assessmentType as keyof typeof answers]?.find((a: { questionId: string }) => a.questionId === question.id);
      
    if (existingAnswer) {
      if (Array.isArray(existingAnswer.answerId)) {
        setSelectedOptions(existingAnswer.answerId as string[]);
      } else {
        setSelectedOption(existingAnswer.answerId as string);
      }
    } else {
      setSelectedOption(null);
      setSelectedOptions([]);
    }
      
    if (question.type === 'memory') {
      setIsMemoryPhase(true);
      setShowMemoryItems(true);
        
      const timer = setTimeout(() => {
        setShowMemoryItems(false);
      }, 5000);
        
      return () => clearTimeout(timer);
    } else {
      setIsMemoryPhase(false);
    }
    
    // 重置序列相关状态
    setIsSequenceRunning(false);
    setCurrentSequenceIndex(-1);
    setSequenceComplete(false);
    if (question.sequenceData) {
      setSequenceOptions(question.sequenceData.options);
    }

    // 重置连接游戏状态
    setConnections([]);
    setConnectionResult(null);
    
    // 如果是连接题型，初始化画布
    if (question.type === 'connection' && canvasRef.current) {
      setTimeout(() => {
        initCanvas();
      }, 100);
    }
  }, [question, answers, assessmentType]);

  // 确保连接题型的画布在组件挂载后初始化
  useEffect(() => {
    if (question.type === 'connection' && canvasRef.current) {
      initCanvas();
    }
  }, []);

  // 当连接发生变化时重绘画布
  useEffect(() => {
    if (question.type === 'connection') {
      drawConnections();
    }
  }, [connections]);

  const initCanvas = () => {
    if (!canvasRef.current || !question.connectionData) return;
    
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    // 设置画布尺寸为容器尺寸
    const container = canvas.parentElement;
    if (container) {
      canvas.width = container.clientWidth;
      canvas.height = container.clientHeight;
    }
    
    // 清除画布
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    // 绘制节点
    question.connectionData.nodes.forEach(node => {
      drawNode(ctx, node);
    });
  };

  const drawNode = (ctx: CanvasRenderingContext2D, node: ConnectionNode) => {
    ctx.beginPath();
    ctx.arc(node.x, node.y, 15, 0, Math.PI * 2);
    ctx.fillStyle = connections.includes(node.id) ? '#10b981' : '#3b82f6';
    ctx.fill();
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 14px Arial';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(node.text, node.x, node.y);
  };

  const drawConnections = () => {
    if (!canvasRef.current || !question.connectionData) return;
    
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    // 清除画布
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    // 绘制连接线
    if (connections.length > 1) {
      ctx.beginPath();
      ctx.strokeStyle = '#3b82f6';
      ctx.lineWidth = 3;
      
      for (let i = 0; i < connections.length - 1; i++) {
        const currentNodeId = connections[i];
        const nextNodeId = connections[i + 1];
        
        const currentNode = question.connectionData.nodes.find(n => n.id === currentNodeId);
        const nextNode = question.connectionData.nodes.find(n => n.id === nextNodeId);
        
        if (currentNode && nextNode) {
          if (i === 0) {
            ctx.moveTo(currentNode.x, currentNode.y);
          }
          ctx.lineTo(nextNode.x, nextNode.y);
        }
      }
      
      ctx.stroke();
    }
    
    // 重新绘制节点（确保节点在线的上面）
    question.connectionData.nodes.forEach(node => {
      drawNode(ctx, node);
    });
  };

  const handleNodeClick = (nodeId: string) => {
    if (!question.connectionData) return;
    
    // 如果节点已经在连接中，不做任何操作
    if (connections.includes(nodeId)) return;
    
    // 添加节点到连接中
    setConnections(prev => [...prev, nodeId]);
  };

  const handleConnectionSubmit = () => {
    if (!question.connectionData) return;
    
    // 检查连接是否正确
    const isCorrect = connections.length === question.connectionData.correctSequence.length && 
                     connections.every((id, index) => id === question.connectionData?.correctSequence[index]);
    
    setConnectionResult(isCorrect);
    
    // 保存答案
    saveAnswer(assessmentType as any, {
      questionId: question.id,
      answerId: question.options[0].id,
      value: isCorrect ? 1 : 0
    });
    
    // 延迟一小段时间后自动进入下一题
    setTimeout(() => {
      onNext();
    }, 1500);
  };

  const handleSingleSelect = (optionId: string, value: number) => {
    setSelectedOption(optionId);
    
    // 保存答案
    saveAnswer(assessmentType as any, {
      questionId: question.id,
      answerId: optionId,
      value: value
    });
    
    // 延迟一小段时间后自动进入下一题
    setTimeout(() => {
      onNext();
    }, 500);
  };

  const handleMultipleSelect = (optionId: string) => {
    setSelectedOptions(prev => {
      const isSelected = prev.includes(optionId);
      return isSelected
        ? prev.filter(id => id !== optionId)
        : [...prev, optionId];
    });
  };

  const handleMultipleSubmit = () => {
    if (selectedOptions.length > 0) {
      const value = selectedOptions.reduce((total, optionId) => {
        const option = question.options.find(opt => opt.id === optionId);
        return total + (option?.value || 0);
      }, 0);
      
      saveAnswer(assessmentType as any, {
        questionId: question.id,
        answerId: selectedOptions,
        value: value
      });
      
      onNext();
    }
  };

  const handleMemoryAcknowledge = () => {
    // Submit the first option's value as the answer
    const firstOption = question.options[0];
    
    saveAnswer(assessmentType as any, {
      questionId: question.id,
      answerId: firstOption.id,
      value: firstOption.value
    });
    
    onNext();
  };
  
  const startSequence = () => {
    if (!question.sequenceData) return;
    
    setIsSequenceRunning(true);
    setCurrentSequenceIndex(0);
    
    const displayTime = question.sequenceData.displayTime;
    const items = question.sequenceData.items;
    
    // 创建一个递归函数来显示序列中的每个项目
    const showSequenceItem = (index: number) => {
      if (index >= items.length) {
        setIsSequenceRunning(false);
        setSequenceComplete(true);
        return;
      }
      
      setCurrentSequenceIndex(index);
      
      setTimeout(() => {
        showSequenceItem(index + 1);
      }, displayTime);
    };
    
    // 开始显示序列
    showSequenceItem(0);
  };

  const renderVisualAid = () => {
    if (!question.visualAid) return null;
    
    return (
      <div className="my-4 border p-4 rounded-md flex justify-center">
        <img 
          src={question.visualAid} 
          alt="视觉辅助" 
          className="max-w-full h-auto max-h-60 object-contain"
        />
      </div>
    );
  };
  
  const renderSequence = () => {
    if (!question.sequenceData) return null;
    
    if (isSequenceRunning) {
      const currentItem = question.sequenceData.items[currentSequenceIndex];
      return (
        <div className="flex justify-center items-center my-8">
          <div className="text-6xl font-bold text-blue-600 animate-pulse">
            {currentItem}
          </div>
        </div>
      );
    }
    
    if (sequenceComplete) {
      return (
        <div className="my-4">
          <h4 className="font-medium text-gray-800 mb-3">{question.sequenceData.question}</h4>
          <div className="space-y-3">
            {sequenceOptions.map(option => (
              <div
                key={option.id}
                onClick={() => handleSingleSelect(option.id, option.value)}
                className={`
                  p-3 border rounded-md cursor-pointer transition-all
                  ${selectedOption === option.id
                    ? 'border-blue-500 bg-blue-50'
                    : 'border-gray-200 hover:border-blue-300 hover:bg-blue-50'
                  }
                `}
              >
                <div className="flex items-center">
                  <div className={`
                    w-5 h-5 rounded-full border flex items-center justify-center mr-3
                    ${selectedOption === option.id
                      ? 'border-blue-500 bg-blue-500'
                      : 'border-gray-300'
                    }
                  `}>
                    {selectedOption === option.id && (
                      <Check className="w-3 h-3 text-white" />
                    )}
                  </div>
                  <span className="text-gray-800">{option.text}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      );
    }
    
    return (
      <div className="my-4">
        <button
          onClick={startSequence}
          className="w-full py-3 bg-blue-600 text-white font-medium rounded-md hover:bg-blue-700 transition-colors focus:ring focus:ring-blue-300 focus:outline-none"
        >
          {question.options[0].text}
        </button>
      </div>
    );
  };

  const renderConnection = () => {
    if (!question.connectionData) return null;
    
    return (
      <div className="my-4">
        <div className="mb-4 p-4 bg-blue-50 border border-blue-200 rounded-md">
          <p className="text-blue-800">{question.description}</p>
        </div>
        
        <div className="relative border rounded-md overflow-hidden" style={{ height: '300px' }}>
          <canvas 
            ref={canvasRef}
            className="w-full h-full cursor-pointer"
            onClick={(e) => {
              if (!question.connectionData) return;
              
              const rect = canvasRef.current?.getBoundingClientRect();
              if (!rect) return;
              
              const x = e.clientX - rect.left;
              const y = e.clientY - rect.top;
              
              // 检查是否点击了某个节点
              const clickedNode = question.connectionData.nodes.find(node => {
                const dx = node.x - x;
                const dy = node.y - y;
                return Math.sqrt(dx * dx + dy * dy) <= 15; // 15是节点半径
              });
              
              if (clickedNode) {
                handleNodeClick(clickedNode.id);
              }
            }}
          />
        </div>
        
        {connectionResult !== null && (
          <div className={`mt-4 p-3 rounded-md ${connectionResult ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
            {connectionResult ? '连接正确！' : '连接错误，请查看正确顺序：1-2-3-4-5-甲-乙-丙-丁-戊'}
          </div>
        )}
        
        <div className="mt-4 flex justify-between">
          <button
            onClick={() => {
              setConnections([]);
              setConnectionResult(null);
              initCanvas();
            }}
            className="px-4 py-2 bg-gray-200 text-gray-700 rounded-md hover:bg-gray-300 transition-colors"
          >
            重置
          </button>
          
          <button
            onClick={handleConnectionSubmit}
            disabled={connections.length < question.connectionData.correctSequence.length}
            className={`
              px-6 py-2 rounded-md font-medium
              ${connections.length < question.connectionData.correctSequence.length
                ? 'bg-gray-200 text-gray-500 cursor-not-allowed'
                : 'bg-blue-600 text-white hover:bg-blue-700'
              }
            `}
          >
            提交
          </button>
        </div>
      </div>
    );
  };

  return (
    <div className="animate-fadeIn">
      <div className="mb-6">
        <h3 className="text-xl font-semibold text-gray-800 mb-2">{question.text}</h3>
        {question.description && !isMemoryPhase && question.type !== 'connection' && (
          <p className="text-gray-600 text-sm">{question.description}</p>
        )}
      </div>
      
      {renderVisualAid()}
      
      {question.type === 'memory' && isMemoryPhase ? (
        <div className="mb-6">
          {showMemoryItems ? (
            <div className="p-4 bg-blue-50 border border-blue-200 rounded-md mb-4">
              <p className="font-medium text-blue-800 mb-2">请记住以下内容：</p>
              <div className="flex flex-wrap gap-2">
                <p className="text-blue-700">{question.description}</p>
              </div>
              <p className="text-sm text-blue-600 mt-2">内容将在5秒后消失</p>
            </div>
          ) : (
            <button
              onClick={handleMemoryAcknowledge}
              className="w-full py-3 bg-blue-600 text-white font-medium rounded-md hover:bg-blue-700 transition-colors focus:ring focus:ring-blue-300 focus:outline-none"
            >
              我已记住，继续测试
            </button>
          )}
        </div>
      ) : question.type === 'sequence' ? (
        renderSequence()
      ) : question.type === 'connection' ? (
        renderConnection()
      ) : (
        <>
          <div className="mb-8">
          {question.type === 'single' && (
            <div className="space-y-3">
              {options.map(option => (
                <div
                  key={option.id}
                  onClick={() => handleSingleSelect(option.id, option.value)}
                  className={`
                    p-3 border rounded-md cursor-pointer transition-all
                    ${selectedOption === option.id
                      ? 'border-blue-500 bg-blue-50'
                      : 'border-gray-200 hover:border-blue-300 hover:bg-blue-50'
                    }
                  `}
                >
                  <div className="flex items-center">
                    <div className={`
                      w-5 h-5 rounded-full border flex items-center justify-center mr-3
                      ${selectedOption === option.id
                        ? 'border-blue-500 bg-blue-500'
                        : 'border-gray-300'
                      }
                    `}>
                      {selectedOption === option.id && (
                        <Check className="w-3 h-3 text-white" />
                      )}
                    </div>
                    <span className="text-gray-800">{option.text}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
            
            {question.type === 'multiple' && (
              <div className="space-y-3">
                {question.options.map(option => (
                  <div
                    key={option.id}
                    onClick={() => handleMultipleSelect(option.id)}
                    className={`
                      p-3 border rounded-md cursor-pointer transition-all
                      ${selectedOptions.includes(option.id)
                        ? 'border-blue-500 bg-blue-50'
                        : 'border-gray-200 hover:border-blue-300 hover:bg-blue-50'
                      }
                    `}
                  >
                    <div className="flex items-center">
                      <div className={`
                        w-5 h-5 rounded border flex items-center justify-center mr-3
                        ${selectedOptions.includes(option.id)
                          ? 'border-blue-500 bg-blue-500'
                          : 'border-gray-300'
                        }
                      `}>
                        {selectedOptions.includes(option.id) && (
                          <Check className="w-3 h-3 text-white" />
                        )}
                      </div>
                      <span className="text-gray-800">{option.text}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
          
          <div className="flex justify-between">
            <button
              onClick={onPrev}
              disabled={isFirst}
              className={`
                px-4 py-2 rounded-md flex items-center
                ${isFirst
                  ? 'text-gray-400 cursor-not-allowed'
                  : 'text-gray-700 hover:bg-gray-100'
                }
              `}
            >
              <ArrowLeft className="w-4 h-4 mr-1" />
              上一题
            </button>
            
            {question.type === 'multiple' ? (
              <button
                onClick={handleMultipleSubmit}
                disabled={selectedOptions.length === 0}
                className={`
                  px-6 py-2 rounded-md font-medium flex items-center
                  ${selectedOptions.length === 0
                    ? 'bg-gray-200 text-gray-500 cursor-not-allowed'
                    : 'bg-blue-600 text-white hover:bg-blue-700'
                  }
                `}
              >
                {isLast ? '完成' : '下一题'}
                <ArrowRight className="w-4 h-4 ml-1" />
              </button>
            ) : null}
          </div>
        </>
      )}
    </div>
  );
};

export default Question;