import React, { useState, useEffect } from 'react';
import { useAssessment } from '../context/AssessmentContext';
import { useProfile } from '../context/ProfileContext';
import Question from './Question';
import { hamaQuestions } from '../data/hamaQuestions';
import { hamdQuestions } from '../data/hamdQuestions';
import { mmseQuestions } from '../data/mmseQuestions';
import { mocaQuestions } from '../data/mocaQuestions';
import { QuestionData } from '../types/question';
import { Activity, HeartPulse, Brain, Clipboard } from 'lucide-react';

interface AssessmentContainerProps {
  onComplete: () => void;
}

const AssessmentContainer: React.FC<AssessmentContainerProps> = () => {
  const { 
    currentAssessment, 
    setCurrentAssessment, 
    calculateScore,
    interpretScore,
    userInfo,
    updateUserInfo,
    answers
  } = useAssessment();
  
  const { currentProfile, addTestRecord } = useProfile();
  
  const [showUserInfoForm, setShowUserInfoForm] = useState(true);
  const [showAssessmentSelection, setShowAssessmentSelection] = useState(true);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  
  const questionsMap: Record<string, any> = {
    hama: hamaQuestions,
    hamd: hamdQuestions,
    mmse: mmseQuestions(),  // mmseQuestions is a function that needs to be called
    moca: mocaQuestions,
  };
  
  const questions = currentAssessment ? questionsMap[currentAssessment] : [];
  const currentQuestion = questions[currentQuestionIndex] as QuestionData;
  
  // 重置问题索引当评估类型改变时
  useEffect(() => {
    setCurrentQuestionIndex(0);
  }, [currentAssessment]);
  
  const handleNext = () => {
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
      // 滚动到页面顶部
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      handleTestComplete();
    }
  };
  
  const handlePrev = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(currentQuestionIndex - 1);
      // 滚动到页面顶部
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };
  
  // 计算当前进度
  const calculateProgress = () => {
    if (!currentAssessment) return 0;
    return Math.round((currentQuestionIndex / questions.length) * 100);
  };
  
  const handleUserInfoSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setShowUserInfoForm(false);
  };

  const handleSelectAssessment = (assessment: string) => {
    setCurrentAssessment(assessment as any);
    setShowAssessmentSelection(false);
  };

  const isAssessmentComplete = (assessment: string) => {
    const assessmentQuestions = assessment === 'mmse' 
      ? mmseQuestions() 
      : assessment === 'hama' 
        ? hamaQuestions 
        : assessment === 'hamd' 
          ? hamdQuestions 
          : mocaQuestions;
    
    return answers[assessment as keyof typeof answers].length === assessmentQuestions.length;
  };

  const handleTestComplete = () => {
    // 如果有用户档案，保存测试记录
    if (currentProfile && currentAssessment) {
      const score = calculateScore(currentAssessment);
      const interpretation = interpretScore(currentAssessment, score);
      
      addTestRecord(currentProfile.id, {
        type: currentAssessment,
        score,
        interpretation,
        date: new Date().toISOString()
      });
    }
    
    // 返回到测试选择界面
    setShowAssessmentSelection(true);
    setCurrentQuestionIndex(0);
  };

  const assessmentCards = [
    { 
      id: 'hama', 
      name: 'HAMA', 
      fullName: '汉密尔顿焦虑量表',
      description: '评估焦虑症状及其严重程度',
      icon: <Activity className="h-6 w-6 text-blue-600" />,
      color: 'bg-blue-50 border-blue-200'
    },
    { 
      id: 'hamd', 
      name: 'HAMD', 
      fullName: '汉密尔顿抑郁量表',
      description: '评估抑郁症状及其严重程度',
      icon: <HeartPulse className="h-6 w-6 text-purple-600" />,
      color: 'bg-purple-50 border-purple-200'
    },
    { 
      id: 'mmse', 
      name: 'MMSE', 
      fullName: '简易精神状态检查',
      description: '评估基本认知功能',
      icon: <Brain className="h-6 w-6 text-green-600" />,
      color: 'bg-green-50 border-green-200'
    },
    { 
      id: 'moca', 
      name: 'MoCA', 
      fullName: '蒙特利尔认知评估',
      description: '敏感筛查轻度认知障碍',
      icon: <Clipboard className="h-6 w-6 text-amber-600" />,
      color: 'bg-amber-50 border-amber-200'
    },
  ];

  return (
    <div className="bg-white rounded-lg shadow-md p-6 animate-fadeIn">
      {showUserInfoForm ? (
        <div className="animate-fadeIn">
          <h2 className="text-xl font-semibold text-gray-800 mb-4">个人信息</h2>
          <p className="text-gray-600 mb-6">请填写以下信息，以便我们提供更准确的评估结果</p>
          
          <form onSubmit={handleUserInfoSubmit}>
            <div className="space-y-4">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">姓名</label>
                <input
                  type="text"
                  id="name"
                  value={userInfo.name}
                  onChange={(e) => updateUserInfo({ name: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">性别</label>
                <div className="flex space-x-4">
                  <label className="flex items-center">
                    <input
                      type="radio"
                      name="gender"
                      value="male"
                      checked={userInfo.gender === 'male'}
                      onChange={() => updateUserInfo({ gender: 'male' })}
                      className="mr-2"
                    />
                    男
                  </label>
                  <label className="flex items-center">
                    <input
                      type="radio"
                      name="gender"
                      value="female"
                      checked={userInfo.gender === 'female'}
                      onChange={() => updateUserInfo({ gender: 'female' })}
                      className="mr-2"
                    />
                    女
                  </label>
                  <label className="flex items-center">
                    <input
                      type="radio"
                      name="gender"
                      value="other"
                      checked={userInfo.gender === 'other'}
                      onChange={() => updateUserInfo({ gender: 'other' })}
                      className="mr-2"
                    />
                    其他
                  </label>
                </div>
              </div>
              
              <div>
                <label htmlFor="birthDate" className="block text-sm font-medium text-gray-700 mb-1">出生日期</label>
                <input
                  type="date"
                  id="birthDate"
                  value={userInfo.birthDate}
                  onChange={(e) => updateUserInfo({ birthDate: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>
              
              <div>
                <label htmlFor="education" className="block text-sm font-medium text-gray-700 mb-1">教育程度</label>
                <select
                  id="education"
                  value={userInfo.education}
                  onChange={(e) => updateUserInfo({ education: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                >
                  <option value="">请选择</option>
                  <option value="primary">小学及以下</option>
                  <option value="secondary">中学/中专</option>
                  <option value="college">大学及以上</option>
                </select>
              </div>
            </div>
            
            <div className="mt-6">
              <button
                type="submit"
                className="w-full py-3 bg-blue-600 text-white font-medium rounded-md hover:bg-blue-700 transition-colors focus:ring focus:ring-blue-300 focus:outline-none"
              >
                开始测试
              </button>
            </div>
          </form>
        </div>
      ) : showAssessmentSelection ? (
        <div className="animate-fadeIn">
          <h2 className="text-xl font-semibold text-gray-800 mb-4">选择评估量表</h2>
          <p className="text-gray-600 mb-6">请选择一种评估量表开始测试，完成一项测试后可以选择其他量表</p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {assessmentCards.map(assessment => {
              const complete = isAssessmentComplete(assessment.id);
              
              return (
                <div 
                  key={assessment.id}
                  onClick={() => handleSelectAssessment(assessment.id)}
                  className={`
                    border rounded-lg p-4 cursor-pointer transition-all hover:shadow-md
                    ${assessment.color} ${complete ? 'border-green-500' : 'border-gray-200'}
                  `}
                >
                  <div className="flex items-start">
                    <div className="p-2 rounded-md mr-3 bg-white">
                      {assessment.icon}
                    </div>
                    <div>
                      <div className="flex items-center">
                        <h3 className="font-medium text-gray-800">{assessment.fullName}</h3>
                        {complete && (
                          <span className="ml-2 px-2 py-0.5 text-xs bg-green-100 text-green-800 rounded-full">
                            已完成
                          </span>
                        )}
                      </div>
                      <p className="text-sm text-gray-600 mt-1">{assessment.description}</p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      ) : (
        <>
          <div className="mb-4 flex justify-between items-center">
            <h2 className="text-lg font-semibold text-gray-800">
              {assessmentCards.find(a => a.id === currentAssessment)?.fullName || '测试中'}
            </h2>
            
            <div className="flex items-center">
              <span className="text-sm font-medium text-gray-700 mr-2">
                问题 {currentQuestionIndex + 1} / {questions.length}
              </span>
              <span className="text-sm font-medium text-gray-700">
                完成度: {calculateProgress()}%
              </span>
            </div>
          </div>
          
          <div className="mb-4">
            <div className="w-full bg-gray-200 rounded-full h-2.5">
              <div 
                className="bg-blue-600 h-2.5 rounded-full transition-all duration-300 ease-out" 
                style={{ width: `${calculateProgress()}%` }}
              ></div>
            </div>
          </div>
          
          {currentAssessment && currentQuestion && (
            <Question 
              question={currentQuestion} 
              assessmentType={currentAssessment}
              onNext={currentQuestionIndex < questions.length - 1 ? handleNext : handleTestComplete}
              onPrev={handlePrev}
              isFirst={currentQuestionIndex === 0}
              isLast={currentQuestionIndex === questions.length - 1}
            />
          )}
        </>
      )}
    </div>
  );
};

export default AssessmentContainer;