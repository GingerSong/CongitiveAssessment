import React, { useState } from 'react';
import { useAssessment } from '../context/AssessmentContext';
import { Activity, HeartPulse, Brain, Clipboard, Printer, RotateCcw, Users } from 'lucide-react';

interface ResultsProps {
  onRestart: () => void;
  onViewProfile?: () => void;
}

const Results: React.FC<ResultsProps> = ({ onRestart, onViewProfile }) => {
  const { 
    userInfo, 
    calculateScore, 
    interpretScore, 
    resetAnswers
  } = useAssessment();
  
  const [activeTab, setActiveTab] = useState<'summary' | 'detail'>('summary');
  
  const scores = {
    hama: calculateScore('hama'),
    hamd: calculateScore('hamd'),
    mmse: calculateScore('mmse'),
    moca: calculateScore('moca'),
  };
  
  const interpretations = {
    hama: interpretScore('hama', scores.hama),
    hamd: interpretScore('hamd', scores.hamd),
    mmse: interpretScore('mmse', scores.mmse),
    moca: interpretScore('moca', scores.moca),
  };
  
  const handlePrint = () => {
    window.print();
  };
  
  const handleRestart = () => {
    resetAnswers();
    onRestart();
  };
  
  const getScoreColor = (assessment: 'hama' | 'hamd' | 'mmse' | 'moca', score: number) => {
    switch (assessment) {
      case 'hama':
        if (score < 7) return 'text-green-600';
        if (score < 14) return 'text-yellow-600';
        return 'text-red-600';
      
      case 'hamd':
        if (score < 8) return 'text-green-600';
        if (score < 17) return 'text-yellow-600';
        return 'text-red-600';
      
      case 'mmse':
        const threshold = userInfo.education === 'primary' ? 17 :
                        userInfo.education === 'secondary' ? 20 : 24;
        return score >= threshold ? 'text-green-600' : 'text-red-600';
      
      case 'moca':
        return score >= 26 ? 'text-green-600' : 'text-yellow-600';
      
      default:
        return 'text-gray-900';
    }
  };
  
  const assessmentInfo = [
    {
      id: 'hama',
      name: '汉密尔顿焦虑量表 (HAMA)',
      icon: <Activity className="h-6 w-6" />,
      score: scores.hama,
      maxScore: 56,
      interpretation: interpretations.hama,
      description: '评估焦虑症状及其严重程度的工具，得分越高表示焦虑症状越严重。',
      scoreGuide: [
        { range: '0-7', meaning: '无明显焦虑', color: 'bg-green-100 text-green-800' },
        { range: '8-13', meaning: '可能存在轻度焦虑', color: 'bg-yellow-100 text-yellow-800' },
        { range: '14-20', meaning: '存在中度焦虑', color: 'bg-orange-100 text-orange-800' },
        { range: '21-29', meaning: '存在重度焦虑', color: 'bg-red-100 text-red-800' },
        { range: '≥30', meaning: '存在极重度焦虑', color: 'bg-red-100 text-red-800' },
      ]
    },
    {
      id: 'hamd',
      name: '汉密尔顿抑郁量表 (HAMD)',
      icon: <HeartPulse className="h-6 w-6" />,
      score: scores.hamd,
      maxScore: 52,
      interpretation: interpretations.hamd,
      description: '评估抑郁症状及其严重程度的工具，得分越高表示抑郁症状越严重。',
      scoreGuide: [
        { range: '0-7', meaning: '无抑郁症状', color: 'bg-green-100 text-green-800' },
        { range: '8-16', meaning: '可能存在轻度抑郁', color: 'bg-yellow-100 text-yellow-800' },
        { range: '17-23', meaning: '存在中度抑郁', color: 'bg-orange-100 text-orange-800' },
        { range: '≥24', meaning: '存在重度抑郁', color: 'bg-red-100 text-red-800' },
      ]
    },
    {
      id: 'mmse',
      name: '简易精神状态检查 (MMSE)',
      icon: <Brain className="h-6 w-6" />,
      score: scores.mmse,
      maxScore: 30,
      interpretation: interpretations.mmse,
      description: '广泛使用的认知功能筛查工具，评估定向力、记忆力、注意力和计算力、回忆力、语言能力和视觉空间能力。',
      scoreGuide: [
        { 
          range: userInfo.education === 'primary' ? '≥17' : 
                userInfo.education === 'secondary' ? '≥20' : '≥24', 
          meaning: '认知功能正常', 
          color: 'bg-green-100 text-green-800' 
        },
        { 
          range: userInfo.education === 'primary' ? '<17' : 
                userInfo.education === 'secondary' ? '<20' : '<24', 
          meaning: '可能存在认知障碍', 
          color: 'bg-red-100 text-red-800' 
        },
      ]
    },
    {
      id: 'moca',
      name: '蒙特利尔认知评估 (MoCA)',
      icon: <Clipboard className="h-6 w-6" />,
      score: scores.moca,
      maxScore: 30,
      interpretation: interpretations.moca,
      description: '敏感度更高的认知功能评估工具，特别适用于筛查轻度认知障碍。',
      scoreGuide: [
        { range: '≥26', meaning: '认知功能正常', color: 'bg-green-100 text-green-800' },
        { range: '<26', meaning: '可能存在轻度认知障碍', color: 'bg-yellow-100 text-yellow-800' },
      ]
    },
  ];

  return (
    <div className="bg-white rounded-lg shadow-md p-6 animate-fadeIn print:shadow-none">
      <div className="flex justify-between items-center mb-6 print:hidden">
        <h2 className="text-2xl font-bold text-gray-800">评估结果</h2>
        <div className="flex space-x-2">
          <button
            onClick={handlePrint}
            className="flex items-center px-4 py-2 bg-blue-100 text-blue-700 rounded-md hover:bg-blue-200 transition-colors"
          >
            <Printer className="h-4 w-4 mr-1" />
            打印结果
          </button>
          {onViewProfile && (
            <button
              onClick={onViewProfile}
              className="flex items-center px-4 py-2 bg-green-100 text-green-700 rounded-md hover:bg-green-200 transition-colors"
            >
              <Users className="h-4 w-4 mr-1" />
              个人档案
            </button>
          )}
          <button
            onClick={handleRestart}
            className="flex items-center px-4 py-2 bg-gray-100 text-gray-700 rounded-md hover:bg-gray-200 transition-colors"
          >
            <RotateCcw className="h-4 w-4 mr-1" />
            重新测试
          </button>
        </div>
      </div>

      <div className="mb-6 print:mb-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 print:grid-cols-4">
          <div className="text-sm">
            <span className="block text-gray-500">姓名</span>
            <span className="font-medium">{userInfo.name}</span>
          </div>
          <div className="text-sm">
            <span className="block text-gray-500">性别</span>
            <span className="font-medium">
              {userInfo.gender === 'male' ? '男' : userInfo.gender === 'female' ? '女' : '其他'}
            </span>
          </div>
          <div className="text-sm">
            <span className="block text-gray-500">出生日期</span>
            <span className="font-medium">{userInfo.birthDate}</span>
          </div>
          <div className="text-sm">
            <span className="block text-gray-500">教育程度</span>
            <span className="font-medium">
              {userInfo.education === 'primary' ? '小学及以下' : 
               userInfo.education === 'secondary' ? '中学/中专' : 
               userInfo.education === 'college' ? '大学及以上' : '未知'}
            </span>
          </div>
        </div>
      </div>
      
      <div className="mb-4 border-b pb-4 print:hidden">
        <div className="flex space-x-4">
          <button
            onClick={() => setActiveTab('summary')}
            className={`
              px-4 py-2 font-medium rounded-md
              ${activeTab === 'summary' 
                ? 'bg-blue-600 text-white' 
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}
            `}
          >
            结果摘要
          </button>
          <button
            onClick={() => setActiveTab('detail')}
            className={`
              px-4 py-2 font-medium rounded-md
              ${activeTab === 'detail' 
                ? 'bg-blue-600 text-white' 
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}
            `}
          >
            详细解读
          </button>
        </div>
      </div>
      
      {(activeTab === 'summary' || true) && (
        <div className="mb-6 print:mb-10">
          <h3 className="text-lg font-semibold text-gray-800 mb-4 print:text-xl">测评结果摘要</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 print:grid-cols-2">
            {assessmentInfo.map(assessment => (
              <div 
                key={assessment.id}
                className="border rounded-lg p-4 transition-all hover:shadow-sm"
              >
                <div className="flex items-start">
                  <div className={`
                    p-2 rounded-md mr-3
                    ${assessment.id === 'hama' ? 'bg-blue-100' : 
                      assessment.id === 'hamd' ? 'bg-purple-100' : 
                      assessment.id === 'mmse' ? 'bg-green-100' : 'bg-amber-100'}
                  `}>
                    {React.cloneElement(assessment.icon, { 
                      className: `h-6 w-6 ${
                        assessment.id === 'hama' ? 'text-blue-600' : 
                        assessment.id === 'hamd' ? 'text-purple-600' : 
                        assessment.id === 'mmse' ? 'text-green-600' : 'text-amber-600'
                      }`
                    })}
                  </div>
                  <div>
                    <h4 className="font-medium text-gray-800">{assessment.name}</h4>
                    <div className="flex items-baseline mt-1">
                      <span className={`text-2xl font-bold ${getScoreColor(assessment.id as any, assessment.score)}`}>
                        {assessment.score}
                      </span>
                      <span className="text-gray-500 text-sm ml-1">/ {assessment.maxScore}</span>
                    </div>
                    <p className="text-sm mt-2">{assessment.interpretation}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
      
      {(activeTab === 'detail' || true) && (
        <div className="space-y-8 print:space-y-10">
          <h3 className="text-lg font-semibold text-gray-800 mb-4 print:text-xl print:page-break-before">详细解读</h3>
          
          {assessmentInfo.map(assessment => (
            <div key={assessment.id} className="border-t pt-6 first:border-t-0 first:pt-0 print:page-break-inside-avoid">
              <h4 className="text-lg font-medium text-gray-800 mb-2">{assessment.name}</h4>
              <p className="text-gray-600 mb-4">{assessment.description}</p>
              
              <div className="flex items-center mb-4">
                <div className="w-full bg-gray-200 rounded-full h-3">
                  <div 
                    className={`
                      h-3 rounded-full transition-all duration-500 ease-out
                      ${assessment.id === 'hama' ? 'bg-blue-600' : 
                        assessment.id === 'hamd' ? 'bg-purple-600' : 
                        assessment.id === 'mmse' ? 'bg-green-600' : 'bg-amber-600'}
                    `}
                    style={{ width: `${(assessment.score / assessment.maxScore) * 100}%` }}
                  ></div>
                </div>
                <span className={`ml-3 font-bold ${getScoreColor(assessment.id as any, assessment.score)}`}>
                  {assessment.score}
                </span>
                <span className="text-gray-500 text-sm ml-1">/ {assessment.maxScore}</span>
              </div>
              
              <div className="mb-4">
                <h5 className="font-medium text-gray-700 mb-2">结果解释</h5>
                <p className="text-gray-800 font-medium">{assessment.interpretation}</p>
              </div>
              
              <div>
                <h5 className="font-medium text-gray-700 mb-2">评分参考</h5>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
                  {assessment.scoreGuide.map((guide, idx) => (
                    <div key={idx} className={`px-3 py-2 rounded-md ${guide.color}`}>
                      <span className="font-medium">{guide.range}</span>: {guide.meaning}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ))}
          
          <div className="border-t pt-6 print:page-break-inside-avoid">
            <h4 className="text-lg font-medium text-gray-800 mb-2">注意事项</h4>
            <div className="bg-gray-50 p-4 rounded-md">
              <p className="text-gray-700 mb-2">本测试结果仅供参考，不能替代专业医疗诊断。如果您担心自己的认知状况或心理健康，请咨询专业医疗人员。</p>
              <p className="text-gray-700">如果测试结果显示可能存在认知障碍或焦虑抑郁症状，建议您尽早咨询相关专科医生，进行进一步的评估和诊断。</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Results;