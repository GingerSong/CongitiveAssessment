import React from 'react';
import { ClipboardList, BookOpen } from 'lucide-react';

interface IntroductionProps {
  onStart: () => void;
  onEducation?: () => void;
}

const Introduction: React.FC<IntroductionProps> = ({ onStart, onEducation }) => {
  return (
    <div className="max-w-3xl mx-auto">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-4">认知功能自我评估工具</h1>
        <p className="text-lg text-gray-600">
          通过科学量表评估认知健康状况，及早发现潜在问题
        </p>
      </div>
      
      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <h2 className="text-xl font-semibold text-gray-800 mb-4">关于本工具</h2>
        <p className="text-gray-600 mb-4">
          本工具提供多种国际认可的认知功能评估量表，包括MMSE（简易精神状态检查）、MoCA（蒙特利尔认知评估）、
          HAMA（汉密尔顿焦虑量表）和HAMD（汉密尔顿抑郁量表）。这些评估可以帮助您了解自己或家人的认知健康状况。
        </p>
        <p className="text-gray-600 mb-4">
          请注意，这些评估结果仅供参考，不能替代专业医疗诊断。如果您对结果有任何疑虑，请咨询医疗专业人员。
        </p>
        
        <div className="flex flex-col sm:flex-row gap-4 mt-6">
          <button
            onClick={onStart}
            className="flex-1 py-3 bg-blue-600 text-white font-semibold rounded-md hover:bg-blue-700 transition-colors flex items-center justify-center"
          >
            <ClipboardList className="h-5 w-5 mr-2" />
            开始评估
          </button>
          
          {onEducation && (
            <button
              onClick={onEducation}
              className="flex-1 py-3 bg-green-600 text-white font-semibold rounded-md hover:bg-green-700 transition-colors flex items-center justify-center"
            >
              <BookOpen className="h-5 w-5 mr-2" />
              浏览科普内容
            </button>
          )}
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-3">评估内容</h3>
          <ul className="space-y-2 text-gray-600">
            <li>• 记忆力与注意力</li>
            <li>• 语言能力与理解力</li>
            <li>• 视觉空间能力</li>
            <li>• 执行功能</li>
            <li>• 情绪状态评估</li>
          </ul>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-3">使用建议</h3>
          <ul className="space-y-2 text-gray-600">
            <li>• 选择安静、不受干扰的环境</li>
            <li>• 确保充分休息后进行评估</li>
            <li>• 诚实回答每个问题</li>
            <li>• 定期进行评估，追踪变化</li>
            <li>• 与家人一起完成可提高准确性</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default Introduction;