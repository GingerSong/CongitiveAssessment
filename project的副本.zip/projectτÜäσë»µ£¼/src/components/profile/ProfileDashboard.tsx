import React, { useState } from 'react';
import { useProfile } from '../../context/ProfileContext';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Calendar, Clock, AlertCircle, Activity, HeartPulse, Brain, Clipboard, ArrowLeft, Users, ClipboardList } from 'lucide-react';
import ProfileSelector from './ProfileSelector';

interface ProfileDashboardProps {
  onBack?: () => void;
  onGoToFamily?: () => void;
}

const ProfileDashboard: React.FC<ProfileDashboardProps> = ({ onBack, onGoToFamily }) => {
  const { currentProfile, getRiskAnalysis } = useProfile();
  const [activeTab, setActiveTab] = useState<'overview' | 'history' | 'health' | 'reminders'>('overview');
  
  if (!currentProfile) {
    return <ProfileSelector />;
  }

  // 获取风险分析
  const riskAnalysis = getRiskAnalysis(currentProfile.id);
  
  // 准备图表数据
  const chartData = currentProfile.testRecords
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
    .reduce((acc: any[], record) => {
      const date = new Date(record.date).toLocaleDateString();
      const existingDate = acc.find(item => item.date === date);
      
      if (existingDate) {
        existingDate[record.type] = record.score;
      } else {
        const newEntry: any = { date };
        newEntry[record.type] = record.score;
        acc.push(newEntry);
      }
      
      return acc;
    }, []);
  
  // 获取即将到来的提醒
  const upcomingReminders = currentProfile.reminders
    .filter(reminder => !reminder.completed && new Date(reminder.date) >= new Date())
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
    .slice(0, 5);
  
  // 注意：这部分代码已在历史标签页中使用，不需要单独声明
  // const recentTests = [...currentProfile.testRecords]
  //   .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
  //   .slice(0, 5);

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex justify-between items-center mb-6">
        <div className="flex items-center">
          {onBack && (
            <button 
              onClick={onBack}
              className="mr-3 p-1 rounded-full hover:bg-gray-100"
              aria-label="返回"
              title="返回"
            >
              <ArrowLeft className="h-5 w-5 text-gray-600" />
            </button>
          )}
          <h2 className="text-2xl font-bold text-gray-800">个人认知档案</h2>
        </div>
        <div className="flex items-center">
          <div className="text-sm text-gray-500 mr-4">
            {currentProfile.name} | {new Date(currentProfile.birthDate).toLocaleDateString()}
          </div>
          <button 
            onClick={onBack}
            className="flex items-center px-3 py-1 bg-gray-100 text-gray-700 rounded-md hover:bg-gray-200 transition-colors mr-2"
            aria-label="测试评估"
            title="返回测试评估"
          >
            <ClipboardList className="h-4 w-4 mr-1" />
            测试评估
          </button>
          {onGoToFamily && (
            <button 
              onClick={onGoToFamily}
              className="flex items-center px-3 py-1 bg-blue-100 text-blue-700 rounded-md hover:bg-blue-200 transition-colors"
              aria-label="家庭协作"
              title="前往家庭协作"
            >
              <Users className="h-4 w-4 mr-1" />
              家庭协作
            </button>
          )}
        </div>
      </div>
      
      <div className="mb-6">
        <div className="flex space-x-2 mb-4">
          <button
            onClick={() => setActiveTab('overview')}
            className={`px-4 py-2 rounded-md ${
              activeTab === 'overview' 
                ? 'bg-blue-600 text-white' 
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            总览
          </button>
          <button
            onClick={() => setActiveTab('history')}
            className={`px-4 py-2 rounded-md ${
              activeTab === 'history' 
                ? 'bg-blue-600 text-white' 
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            测试历史
          </button>
          <button
            onClick={() => setActiveTab('health')}
            className={`px-4 py-2 rounded-md ${
              activeTab === 'health' 
                ? 'bg-blue-600 text-white' 
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            健康信息
          </button>
          <button
            onClick={() => setActiveTab('reminders')}
            className={`px-4 py-2 rounded-md ${
              activeTab === 'reminders' 
                ? 'bg-blue-600 text-white' 
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            提醒
          </button>
        </div>
      </div>
      
      {activeTab === 'overview' && (
        <div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div className="border rounded-lg p-4">
              <h3 className="text-lg font-medium text-gray-800 mb-3">认知风险分析</h3>
              <div className={`
                inline-block px-3 py-1 rounded-full text-sm font-medium mb-3
                ${riskAnalysis.level === 'low' ? 'bg-green-100 text-green-800' : 
                  riskAnalysis.level === 'medium' ? 'bg-yellow-100 text-yellow-800' : 
                  'bg-red-100 text-red-800'}
              `}>
                {riskAnalysis.level === 'low' ? '低风险' : 
                 riskAnalysis.level === 'medium' ? '中等风险' : 
                 '高风险'}
              </div>
              
              {riskAnalysis.factors.length > 0 ? (
                <ul className="space-y-2">
                  {riskAnalysis.factors.map((factor, index) => (
                    <li key={index} className="flex items-start">
                      <AlertCircle className="h-5 w-5 text-yellow-500 mr-2 flex-shrink-0 mt-0.5" />
                      <span className="text-gray-700">{factor}</span>
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="text-gray-700">未检测到明显风险因素</p>
              )}
            </div>
            
            <div className="border rounded-lg p-4">
              <h3 className="text-lg font-medium text-gray-800 mb-3">即将到来的提醒</h3>
              {upcomingReminders.length > 0 ? (
                <ul className="space-y-3">
                  {upcomingReminders.map(reminder => (
                    <li key={reminder.id} className="flex items-start">
                      <div className={`
                        p-2 rounded-md mr-3 flex-shrink-0
                        ${reminder.type === 'test' ? 'bg-blue-100' : 
                          reminder.type === 'medication' ? 'bg-purple-100' : 
                          reminder.type === 'appointment' ? 'bg-green-100' : 
                          'bg-amber-100'}
                      `}>
                        {reminder.type === 'test' ? <Clipboard className="h-4 w-4 text-blue-600" /> : 
                         reminder.type === 'medication' ? <Activity className="h-4 w-4 text-purple-600" /> : 
                         reminder.type === 'appointment' ? <Calendar className="h-4 w-4 text-green-600" /> : 
                         <Clock className="h-4 w-4 text-amber-600" />}
                      </div>
                      <div>
                        <div className="font-medium text-gray-800">{reminder.title}</div>
                        <div className="text-sm text-gray-500">
                          {new Date(reminder.date).toLocaleDateString()} {reminder.time}
                        </div>
                        {reminder.description && (
                          <div className="text-sm text-gray-600 mt-1">{reminder.description}</div>
                        )}
                      </div>
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="text-gray-500">没有即将到来的提醒</p>
              )}
            </div>
          </div>
          
          <div className="border rounded-lg p-4">
            <h3 className="text-lg font-medium text-gray-800 mb-4">测试趋势</h3>
            {chartData.length > 0 ? (
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={chartData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="hama" name="HAMA" stroke="#3b82f6" activeDot={{ r: 8 }} />
                    <Line type="monotone" dataKey="hamd" name="HAMD" stroke="#8b5cf6" activeDot={{ r: 8 }} />
                    <Line type="monotone" dataKey="mmse" name="MMSE" stroke="#10b981" activeDot={{ r: 8 }} />
                    <Line type="monotone" dataKey="moca" name="MoCA" stroke="#f59e0b" activeDot={{ r: 8 }} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <p className="text-center text-gray-500">暂无测试数据</p>
            )}
          </div>
        </div>
      )}
      
      {activeTab === 'history' && (
        <div>
          <h3 className="text-lg font-medium text-gray-800 mb-4">测试历史记录</h3>
          {currentProfile.testRecords.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">日期</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">测试类型</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">分数</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">结果解释</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {[...currentProfile.testRecords]
                    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                    .map(record => (
                      <tr key={record.id}>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {new Date(record.date).toLocaleDateString()}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <div className={`
                              p-1 rounded-md mr-2
                              ${record.type === 'hama' ? 'bg-blue-100' : 
                                record.type === 'hamd' ? 'bg-purple-100' : 
                                record.type === 'mmse' ? 'bg-green-100' : 
                                'bg-amber-100'}
                            `}>
                              {record.type === 'hama' ? <Activity className="h-4 w-4 text-blue-600" /> : 
                               record.type === 'hamd' ? <HeartPulse className="h-4 w-4 text-purple-600" /> : 
                               record.type === 'mmse' ? <Brain className="h-4 w-4 text-green-600" /> : 
                               <Clipboard className="h-4 w-4 text-amber-600" />}
                            </div>
                            <span className="text-sm font-medium text-gray-900">
                              {record.type === 'hama' ? '汉密尔顿焦虑量表' : 
                               record.type === 'hamd' ? '汉密尔顿抑郁量表' : 
                               record.type === 'mmse' ? '简易精神状态检查' : 
                               '蒙特利尔认知评估'}
                            </span>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                          {record.score}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {record.interpretation}
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          ) : (
            <p className="text-center text-gray-500">暂无测试记录</p>
          )}
        </div>
      )}
      
      {activeTab === 'health' && (
        <div>
          <h3 className="text-lg font-medium text-gray-800 mb-4">健康信息管理</h3>
          {currentProfile.healthInfo.length > 0 ? (
            <div className="space-y-4">
              {[...currentProfile.healthInfo]
                .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                .map(info => (
                  <div key={info.id} className="border rounded-lg p-4">
                    <div className="flex justify-between items-start">
                      <div>
                        <h4 className="font-medium text-gray-800">{info.title}</h4>
                        <div className="text-sm text-gray-500 mt-1">
                          {new Date(info.date).toLocaleDateString()} | 
                          {info.type === 'medication' ? ' 药物' : 
                           info.type === 'appointment' ? ' 就诊' : ' 笔记'}
                        </div>
                      </div>
                      {info.reminder?.enabled && (
                        <div className="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded-full">
                          已设置提醒
                        </div>
                      )}
                    </div>
                    <p className="text-gray-700 mt-2">{info.description}</p>
                  </div>
                ))}
            </div>
          ) : (
            <p className="text-center text-gray-500">暂无健康信息记录</p>
          )}
        </div>
      )}
      
      {activeTab === 'reminders' && (
        <div>
          <h3 className="text-lg font-medium text-gray-800 mb-4">提醒管理</h3>
          {currentProfile.reminders.length > 0 ? (
            <div className="space-y-4">
              {[...currentProfile.reminders]
                .sort((a, b) => {
                  if (a.completed && !b.completed) return 1;
                  if (!a.completed && b.completed) return -1;
                  return new Date(a.date).getTime() - new Date(b.date).getTime();
                })
                .map(reminder => (
                  <div 
                    key={reminder.id} 
                    className={`border rounded-lg p-4 ${reminder.completed ? 'bg-gray-50' : ''}`}
                  >
                    <div className="flex items-start">
                      <div className={`
                        p-2 rounded-md mr-3 flex-shrink-0
                        ${reminder.type === 'test' ? 'bg-blue-100' : 
                          reminder.type === 'medication' ? 'bg-purple-100' : 
                          reminder.type === 'appointment' ? 'bg-green-100' : 
                          'bg-amber-100'}
                      `}>
                        {reminder.type === 'test' ? <Clipboard className="h-4 w-4 text-blue-600" /> : 
                         reminder.type === 'medication' ? <Activity className="h-4 w-4 text-purple-600" /> : 
                         reminder.type === 'appointment' ? <Calendar className="h-4 w-4 text-green-600" /> : 
                         <Clock className="h-4 w-4 text-amber-600" />}
                      </div>
                      <div className="flex-grow">
                        <div className="flex justify-between items-start">
                          <div>
                            <h4 className={`font-medium ${reminder.completed ? 'text-gray-500 line-through' : 'text-gray-800'}`}>
                              {reminder.title}
                            </h4>
                            <div className="text-sm text-gray-500 mt-1">
                              {new Date(reminder.date).toLocaleDateString()} {reminder.time}
                            </div>
                          </div>
                          <div className={`
                            text-xs px-2 py-1 rounded-full
                            ${reminder.completed ? 'bg-gray-100 text-gray-500' : 
                              new Date(`${reminder.date}T${reminder.time}`) < new Date() ? 
                              'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'}
                          `}>
                            {reminder.completed ? '已完成' : 
                             new Date(`${reminder.date}T${reminder.time}`) < new Date() ? '已过期' : '待完成'}
                          </div>
                        </div>
                        {reminder.description && (
                          <p className={`text-sm mt-2 ${reminder.completed ? 'text-gray-400' : 'text-gray-600'}`}>
                            {reminder.description}
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
            </div>
          ) : (
            <p className="text-center text-gray-500">暂无提醒</p>
          )}
        </div>
      )}
    </div>
  );
};

export default ProfileDashboard;