import React, { useState } from 'react';
import { useProfile } from '../../context/ProfileContext';
import { UserPlus, User, Edit, Trash2 } from 'lucide-react';
import ProfileForm from './ProfileForm';

const ProfileSelector: React.FC = () => {
  const { profiles, currentProfile, setCurrentProfile, deleteProfile } = useProfile();
  const [showCreateForm, setShowCreateForm] = useState(false);
  
  if (showCreateForm) {
    return (
      <ProfileForm onComplete={() => setShowCreateForm(false)} />
    );
  }
  
  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-gray-800">选择档案</h2>
        <button
          onClick={() => setShowCreateForm(true)}
          className="flex items-center px-3 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
        >
          <UserPlus className="h-4 w-4 mr-1" />
          创建新档案
        </button>
      </div>
      
      {profiles.length > 0 ? (
        <div className="space-y-4">
          {profiles.map(profile => (
            <div 
              key={profile.id} 
              className={`border rounded-lg p-4 flex justify-between items-center cursor-pointer hover:bg-gray-50 transition-colors ${
                currentProfile?.id === profile.id ? 'border-blue-500 bg-blue-50' : ''
              }`}
              onClick={() => setCurrentProfile(profile.id)}
            >
              <div className="flex items-center">
                <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center mr-3">
                  <User className="h-5 w-5 text-blue-600" />
                </div>
                <div>
                  <div className="font-medium text-gray-800">{profile.name}</div>
                  <div className="text-sm text-gray-500">
                    {profile.gender === 'male' ? '男' : profile.gender === 'female' ? '女' : '其他'} | 
                    {new Date(profile.birthDate).toLocaleDateString()} | 
                    {profile.education === 'primary' ? '小学及以下' : 
                     profile.education === 'secondary' ? '中学/中专' : '大学及以上'}
                  </div>
                </div>
              </div>
              
              <div className="flex space-x-2">
                <button 
                  className="p-1 text-gray-400 hover:text-gray-600"
                  onClick={(e) => {
                    e.stopPropagation();
                    // 编辑功能可以在这里实现
                  }}
                >
                  <Edit className="h-4 w-4" />
                </button>
                <button 
                  className="p-1 text-gray-400 hover:text-red-600"
                  onClick={(e) => {
                    e.stopPropagation();
                    if (window.confirm('确定要删除此档案吗？')) {
                      deleteProfile(profile.id);
                    }
                  }}
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-8">
          <User className="h-12 w-12 text-blue-500 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-800 mb-2">暂无个人档案</h3>
          <p className="text-gray-600 mb-6">创建一个个人档案以保存您的测试记录和健康信息</p>
          <button
            onClick={() => setShowCreateForm(true)}
            className="px-4 py-2 bg-blue-600 text-white font-medium rounded-md hover:bg-blue-700 transition-colors"
          >
            创建个人档案
          </button>
        </div>
      )}
    </div>
  );
};

export default ProfileSelector;