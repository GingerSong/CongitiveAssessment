import React, { useState } from 'react';
import { useProfile } from '../../context/ProfileContext';

interface ProfileFormProps {
  onComplete?: () => void;
}

const ProfileForm: React.FC<ProfileFormProps> = ({ onComplete }) => {
  const { createProfile } = useProfile();
  const [formData, setFormData] = useState({
    name: '',
    gender: 'male' as 'male' | 'female' | 'other',
    birthDate: '',
    education: ''
  });
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createProfile(formData);
    if (onComplete) {
      onComplete();
    }
  };
  
  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-2xl font-bold text-gray-800 mb-6">创建个人档案</h2>
      
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">姓名</label>
          <input
            type="text"
            id="name"
            name="name"
            value={formData.name}
            onChange={handleChange}
            required
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring focus:ring-blue-300 focus:outline-none transition"
            placeholder="请输入您的姓名"
          />
        </div>
        
        <div>
          <label htmlFor="gender" className="block text-sm font-medium text-gray-700 mb-1">性别</label>
          <select
            id="gender"
            name="gender"
            value={formData.gender}
            onChange={handleChange}
            required
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring focus:ring-blue-300 focus:outline-none transition"
          >
            <option value="male">男</option>
            <option value="female">女</option>
            <option value="other">其他</option>
          </select>
        </div>
        
        <div>
          <label htmlFor="birthDate" className="block text-sm font-medium text-gray-700 mb-1">出生日期</label>
          <input
            type="date"
            id="birthDate"
            name="birthDate"
            value={formData.birthDate}
            onChange={handleChange}
            required
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring focus:ring-blue-300 focus:outline-none transition"
          />
        </div>
        
        <div>
          <label htmlFor="education" className="block text-sm font-medium text-gray-700 mb-1">教育程度</label>
          <select
            id="education"
            name="education"
            value={formData.education}
            onChange={handleChange}
            required
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring focus:ring-blue-300 focus:outline-none transition"
          >
            <option value="">请选择</option>
            <option value="primary">小学及以下</option>
            <option value="secondary">中学/中专</option>
            <option value="college">大学及以上</option>
          </select>
        </div>
        
        <div className="pt-4">
          <button
            type="submit"
            className="w-full py-3 bg-blue-600 text-white font-semibold rounded-md hover:bg-blue-700 transition-colors focus:ring focus:ring-blue-300 focus:outline-none"
          >
            创建档案
          </button>
        </div>
      </form>
    </div>
  );
};

export default ProfileForm;