import { useState, useEffect } from 'react';
import Layout from './components/Layout';
import Introduction from './components/Introduction';
import AssessmentContainer from './components/AssessmentContainer';
import Results from './components/Results';
import ProfileDashboard from './components/profile/ProfileDashboard';
import FamilyDashboard from './components/family/FamilyDashboard';
import EducationHub from './components/education/EducationHub';
import { AssessmentProvider } from './context/AssessmentContext';
import { ProfileProvider } from './context/ProfileContext';
import { FamilyProvider } from './context/FamilyContext';
import './index.css';

function App() {
  const [currentScreen, setCurrentScreen] = useState<'intro' | 'assessment' | 'results' | 'profile' | 'family' | 'education'>('intro');
  const [previousScreen, setPreviousScreen] = useState<'intro' | 'assessment' | 'results' | 'profile' | 'family' | 'education' | null>(null);

  // 保存前一个屏幕状态，用于返回功能
  useEffect(() => {
    if (currentScreen !== previousScreen && previousScreen !== null) {
      setPreviousScreen(currentScreen);
    }
  }, [currentScreen]);

  const handleNavigate = (screen: 'intro' | 'assessment' | 'results' | 'profile' | 'family' | 'education') => {
    // 如果当前不在目标屏幕，保存当前屏幕作为前一个屏幕
    if (currentScreen !== screen) {
      setPreviousScreen(currentScreen);
    }
    setCurrentScreen(screen);
  };

  // 根据当前页面确定返回目标
  const getBackTarget = () => {
    if (currentScreen === 'profile') {
      // 如果前一个屏幕是结果页面，返回结果页面，否则返回测试页面
      return previousScreen === 'results' ? 'results' : 'assessment';
    } else if (currentScreen === 'family') {
      // 从家庭页面返回个人档案页面
      return 'profile';
    } else if (currentScreen === 'education') {
      // 从教育页面返回首页
      return 'intro';
    }
    return 'intro';
  };

  return (
    <AssessmentProvider>
      <ProfileProvider>
        <FamilyProvider>
          <Layout currentScreen={currentScreen} onNavigate={handleNavigate}>
            {currentScreen === 'intro' && (
              <Introduction 
                onStart={() => handleNavigate('assessment')} 
                onEducation={() => handleNavigate('education')}
              />
            )}
            {currentScreen === 'assessment' && (
              <AssessmentContainer onComplete={() => handleNavigate('results')} />
            )}
            {currentScreen === 'results' && (
              <Results 
                onRestart={() => handleNavigate('intro')} 
                onViewProfile={() => handleNavigate('profile')}
              />
            )}
            {currentScreen === 'profile' && (
              <ProfileDashboard 
                onBack={() => handleNavigate(getBackTarget())}
                onGoToFamily={() => handleNavigate('family')}
              />
            )}
            {currentScreen === 'family' && (
              <FamilyDashboard 
                onBack={() => handleNavigate('profile')}
              />
            )}
            {currentScreen === 'education' && (
              <EducationHub 
                onBack={() => handleNavigate('intro')}
              />
            )}
          </Layout>
        </FamilyProvider>
      </ProfileProvider>
    </AssessmentProvider>
  );
}

export default App;