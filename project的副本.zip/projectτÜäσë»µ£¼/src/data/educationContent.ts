export interface EducationArticle {
  id: string;
  title: string;
  category: 'basics' | 'activities' | 'prevention' | 'professional';
  summary: string;
  sections: ArticleSection[];
  imageUrl?: string;
}

export interface ArticleSection {
  title: string;
  content?: string;
  type: 'text' | 'list' | 'steps' | 'tips' | 'warning' | 'highlight';
  items?: string[];
  imageUrl?: string;
}

export const educationArticles: EducationArticle[] = [
  // 认知健康基础知识库
  {
    id: 'basics-1',
    title: '什么是认知健康',
    category: 'basics',
    summary: '认知健康是指大脑良好运作的状态，包括学习、记忆、注意力、语言、判断力和执行功能等多个方面。',
    imageUrl: 'https://images.unsplash.com/photo-1559757175-5700dde675bc?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80',
    sections: [
      {
        title: '认知健康的定义',
        type: 'text',
        content: '良好的认知健康使人能够清晰思考、学习新知识、有效沟通、记住重要信息并做出合理决策。随着年龄增长，认知功能可能会出现一定程度的自然衰退，但严重的认知障碍并非正常衰老的一部分。'
      },
      {
        title: '认知健康的关键组成部分',
        type: 'list',
        content: '',
        items: [
          '记忆力：短期和长期记忆的能力',
          '注意力：集中精力并过滤干扰的能力',
          '执行功能：计划、组织和完成任务的能力',
          '语言能力：理解和表达语言的能力',
          '视觉空间能力：理解视觉信息并在空间中导航的能力',
          '处理速度：接收和响应信息的速度'
        ]
      },
      {
        title: '为什么认知健康很重要',
        type: 'highlight',
        content: '维护认知健康对于保持独立生活、维持社交关系和享受高质量生活至关重要。通过了解认知健康的基础知识，我们可以采取积极措施来保护和增强我们的认知功能。'
      }
    ]
  },
  {
    id: 'basics-2',
    title: '认知障碍的常见类型',
    category: 'basics',
    summary: '认知障碍包括多种类型，从轻度认知障碍到严重的痴呆症，了解这些类型有助于早期识别和干预。',
    imageUrl: 'https://images.unsplash.com/photo-1576091160550-2173dba999ef?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80',
    sections: [
      {
        title: '轻度认知障碍(MCI)',
        type: 'list',
        content: '',
        items: [
          '记忆、语言或思维能力的轻微但可测量的变化',
          '通常不影响日常生活活动',
          '可能是痴呆症的早期阶段，但并非所有MCI患者都会发展为痴呆症'
        ]
      },
      {
        title: '阿尔茨海默病',
        type: 'list',
        content: '',
        items: [
          '最常见的痴呆症类型',
          '特征是记忆力下降、思维和行为问题',
          '随着时间推移逐渐恶化'
        ]
      },
      {
        title: '血管性痴呆',
        type: 'list',
        content: '',
        items: [
          '由脑部血流问题引起',
          '常见于中风后',
          '症状可能突然出现或逐渐发展'
        ]
      },
      {
        title: '路易体痴呆',
        type: 'list',
        content: '',
        items: [
          '特征是视觉幻觉和运动问题',
          '可能伴有帕金森病样症状'
        ]
      },
      {
        title: '额颞叶痴呆',
        type: 'list',
        content: '',
        items: [
          '影响大脑的前部和侧部',
          '常见症状包括行为和性格变化、语言困难'
        ]
      },
      {
        title: '早期识别的重要性',
        type: 'warning',
        content: '认知障碍的早期识别对于获得适当的治疗和支持至关重要。如果您或您的亲人出现认知变化，请咨询医疗专业人员进行评估。'
      }
    ]
  },
  
  // 简单干预活动建议
  {
    id: 'activities-1',
    title: '日常认知训练活动',
    category: 'activities',
    summary: '将认知训练融入日常生活可以帮助维持和提高认知功能，同时增加生活乐趣。',
    imageUrl: 'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80',
    sections: [
      {
        title: '思维游戏与益智游戏',
        type: 'list',
        content: '',
        items: [
          '数独、填字游戏、拼图',
          '棋类游戏如象棋、围棋',
          '记忆配对游戏'
        ],
        imageUrl: 'https://images.unsplash.com/photo-1610890716171-6b1bb98ffd09?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80'
      },
      {
        title: '学习新技能',
        type: 'list',
        content: '',
        items: [
          '学习一门新语言',
          '学习演奏乐器',
          '尝试新的烹饪技巧或手工艺'
        ]
      },
      {
        title: '阅读与写作',
        type: 'list',
        content: '',
        items: [
          '定期阅读各类书籍、报纸或杂志',
          '写日记或创意写作',
          '参加读书俱乐部，讨论所读内容'
        ]
      },
      {
        title: '社交活动',
        type: 'list',
        content: '',
        items: [
          '与朋友和家人定期交流',
          '参加社区活动或志愿服务',
          '加入兴趣小组或俱乐部'
        ]
      },
      {
        title: '身体活动',
        type: 'list',
        content: '',
        items: [
          '规律的有氧运动，如散步、游泳或骑自行车',
          '太极拳或瑜伽等结合身心的活动',
          '舞蹈课程，结合记忆、协调和社交元素'
        ]
      },
      {
        title: '活动效益',
        type: 'highlight',
        content: '这些活动不仅有助于维持认知功能，还能提高生活质量和整体健康状况。尝试每天至少进行一项认知训练活动，并定期变换活动类型以全面锻炼大脑不同区域。'
      }
    ]
  },
  {
    id: 'activities-2',
    title: '记忆力增强技巧',
    category: 'activities',
    summary: '通过特定的技巧和策略，我们可以显著提高记忆力和信息处理能力。',
    imageUrl: 'https://images.unsplash.com/photo-1457904375453-3e1fc2fc76f4?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80',
    sections: [
      {
        title: '视觉化和联想',
        type: 'tips',
        content: '',
        items: [
          '将需要记忆的信息与生动的图像联系起来',
          '创建心理图像，将抽象概念转化为具体画面',
          '使用"记忆宫殿"技巧，将信息与熟悉的地点联系起来'
        ]
      },
      {
        title: '分块记忆',
        type: 'tips',
        content: '',
        items: [
          '将长串信息分解成更小、更易管理的部分',
          '例如，将电话号码分成区号、前三位和后四位'
        ]
      },
      {
        title: '首字母缩写和记忆口诀',
        type: 'tips',
        content: '',
        items: [
          '使用首字母创建单词或短语',
          '创建押韵或有节奏的句子来记忆列表或序列'
        ]
      },
      {
        title: '重复和间隔复习',
        type: 'tips',
        content: '',
        items: [
          '定期复习新信息，而不是一次性集中学习',
          '使用间隔重复系统，随着时间的推移逐渐增加复习间隔'
        ]
      },
      {
        title: '多感官学习',
        type: 'tips',
        content: '',
        items: [
          '结合视觉、听觉和动觉方式学习新信息',
          '大声朗读、写下来或教给他人以加强记忆'
        ]
      },
      {
        title: '注意力训练',
        type: 'tips',
        content: '',
        items: [
          '练习正念冥想以提高注意力集中能力',
          '减少分心，专注于当前任务'
        ]
      },
      {
        title: '健康生活方式',
        type: 'highlight',
        content: '保证充足的睡眠，睡眠对记忆巩固至关重要。均衡饮食和规律锻炼也有助于提高记忆力。记住，记忆力就像肌肉，需要定期锻炼才能保持强健。'
      }
    ]
  },
  
  // 风险因素与预防策略指南
  {
    id: 'prevention-1',
    title: '认知障碍的风险因素',
    category: 'prevention',
    summary: '了解认知障碍的风险因素可以帮助我们采取预防措施，降低发生认知问题的可能性。',
    imageUrl: 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80',
    sections: [
      {
        title: '不可改变的风险因素',
        type: 'list',
        content: '',
        items: [
          '年龄：年龄增长是认知障碍最显著的风险因素',
          '家族史：有直系亲属患阿尔茨海默病或其他痴呆症的人风险更高',
          '基因因素：某些基因变异可能增加风险',
          '唐氏综合症：患有唐氏综合症的人更容易发展为阿尔茨海默病'
        ]
      },
      {
        title: '心血管健康问题',
        type: 'warning',
        content: '',
        items: [
          '高血压',
          '高胆固醇',
          '糖尿病',
          '肥胖',
          '心脏病'
        ]
      },
      {
        title: '生活方式因素',
        type: 'list',
        content: '',
        items: [
          '吸烟',
          '过量饮酒',
          '缺乏体育锻炼',
          '不健康饮食',
          '社交隔离',
          '认知不活跃'
        ]
      },
      {
        title: '其他风险因素',
        type: 'list',
        content: '',
        items: [
          '头部创伤：严重或反复的头部创伤可能增加风险',
          '睡眠问题：长期睡眠障碍与认知功能下降有关',
          '抑郁和慢性压力：长期未治疗的抑郁和持续的高压力水平可能影响认知健康'
        ]
      },
      {
        title: '风险管理',
        type: 'highlight',
        content: '虽然我们无法改变年龄或基因，但通过管理可改变的风险因素，如改善生活方式和控制慢性疾病，可以显著降低发展认知障碍的风险。预防始于了解风险。'
      }
    ]
  },
  {
    id: 'prevention-2',
    title: '认知健康的预防策略',
    category: 'prevention',
    summary: '采取积极的预防策略可以帮助维护认知健康，延缓认知衰退，提高生活质量。',
    imageUrl: 'https://images.unsplash.com/photo-1490645935967-10de6ba17061?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80',
    sections: [
      {
        title: '心脏健康就是大脑健康',
        type: 'tips',
        content: '',
        items: [
          '控制血压、胆固醇和血糖水平',
          '保持健康体重',
          '定期体检和管理慢性疾病'
        ]
      },
      {
        title: '均衡饮食',
        type: 'tips',
        content: '',
        items: [
          '遵循地中海饮食或MIND饮食',
          '增加富含抗氧化剂的食物（如浆果、深色叶菜）',
          '摄入富含omega-3脂肪酸的食物（如鱼类）',
          '减少加工食品和糖的摄入'
        ],
        imageUrl: 'https://images.unsplash.com/photo-1512621776951-a57141f2eefd?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80'
      },
      {
        title: '规律锻炼',
        type: 'tips',
        content: '',
        items: [
          '每周至少150分钟中等强度有氧运动',
          '包括力量训练和平衡练习',
          '选择您喜欢并能坚持的活动'
        ]
      },
      {
        title: '保持社交活跃',
        type: 'tips',
        content: '',
        items: [
          '维持强大的社交网络',
          '定期与朋友和家人互动',
          '参与社区活动和志愿服务'
        ]
      },
      {
        title: '精神刺激',
        type: 'tips',
        content: '',
        items: [
          '持续学习新事物',
          '挑战自己的思维',
          '培养多样化的兴趣爱好'
        ]
      },
      {
        title: '质量睡眠',
        type: 'tips',
        content: '',
        items: [
          '保持规律的睡眠时间表',
          '创造有利于睡眠的环境',
          '处理睡眠障碍问题'
        ]
      },
      {
        title: '压力管理',
        type: 'tips',
        content: '',
        items: [
          '学习放松技巧如冥想或深呼吸',
          '保持工作与生活的平衡',
          '寻求支持，必要时咨询专业人士'
        ]
      },
      {
        title: '避免有害习惯',
        type: 'warning',
        content: '',
        items: [
          '戒烟',
          '限制酒精摄入',
          '避免头部创伤（如戴头盔）'
        ]
      },
      {
        title: '管理慢性健康状况',
        type: 'tips',
        content: '',
        items: [
          '积极治疗抑郁、焦虑和其他精神健康问题',
          '控制糖尿病、高血压等慢性疾病'
        ]
      },
      {
        title: '预防的力量',
        type: 'highlight',
        content: '认知健康的预防不是单一行动，而是一系列健康生活方式选择的综合结果。今天开始的小改变可能会对您未来的认知健康产生重大影响。'
      }
    ]
  },
  
  // 何时寻求专业帮助的指导
  {
    id: 'professional-1',
    title: '认知问题的警示信号',
    category: 'professional',
    summary: '了解认知问题的早期警示信号可以帮助及时寻求专业帮助，获得早期干预。',
    imageUrl: 'https://images.unsplash.com/photo-1579684385127-1ef15d508118?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80',
    sections: [
      {
        title: '记忆力问题',
        type: 'warning',
        content: '',
        items: [
          '反复询问相同的问题',
          '频繁忘记近期发生的事情或对话',
          '依赖记忆辅助工具或家人提醒日常事务',
          '错过约会或忘记重要日期'
        ]
      },
      {
        title: '语言和沟通困难',
        type: 'warning',
        content: '',
        items: [
          '难以找到合适的词语表达想法',
          '在对话中迷失或难以跟随',
          '命名困难（难以记住熟悉物品或人的名称）'
        ]
      },
      {
        title: '判断力和解决问题能力下降',
        type: 'warning',
        content: '',
        items: [
          '在处理财务方面出现困难',
          '做出不符合性格的决定',
          '难以计划和执行多步骤任务',
          '对时间或地点感到困惑'
        ]
      },
      {
        title: '日常活动变化',
        type: 'warning',
        content: '',
        items: [
          '难以完成熟悉的任务（如烹饪、驾驶或支付账单）',
          '对曾经喜欢的活动失去兴趣',
          '个人卫生习惯改变',
          '迷路或在熟悉的环境中感到困惑'
        ]
      },
      {
        title: '情绪和行为变化',
        type: 'warning',
        content: '',
        items: [
          '情绪波动或性格改变',
          '增加的焦虑、抑郁或冷漠',
          '社交退缩',
          '判断力差或行为不当'
        ]
      },
      {
        title: '早期干预的重要性',
        type: 'highlight',
        content: '如果您或您的亲人出现这些症状，尤其是当它们干扰日常生活或持续恶化时，应该咨询医疗专业人员。早期干预对于许多认知问题至关重要，可能会显著改善预后和生活质量。'
      }
    ]
  },
  {
    id: 'professional-2',
    title: '如何寻求专业帮助',
    category: 'professional',
    summary: '当出现认知问题时，了解如何寻求和获取专业帮助是至关重要的第一步。',
    imageUrl: 'https://images.unsplash.com/photo-1666214280557-f1b5022eb634?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80',
    sections: [
      {
        title: '首先联系全科医生',
        type: 'steps',
        content: '',
        items: [
          '安排全面体检',
          '讨论您注意到的认知变化',
          '带上药物清单和详细的症状记录',
          '考虑邀请家人或朋友一同前往，提供额外观察'
        ]
      },
      {
        title: '专科转诊',
        type: 'text',
        content: '全科医生可能会转诊给以下专科医生：神经科医生（专门研究大脑和神经系统疾病）、老年精神病学家（专注于老年人心理健康）、老年医学专家（专门治疗老年人健康问题）或神经心理学家（进行详细的认知测试）。'
      },
      {
        title: '评估过程',
        type: 'steps',
        content: '',
        items: [
          '详细的病史和体检',
          '认知筛查测试（如MMSE或MoCA）',
          '实验室检查排除其他原因',
          '脑部影像学检查（如MRI或CT扫描）',
          '全面的神经心理评估'
        ]
      },
      {
        title: '寻找资源和支持',
        type: 'tips',
        content: '',
        items: [
          '阿尔茨海默病协会等组织提供信息和支持',
          '寻找当地支持小组',
          '考虑参与临床试验',
          '探索社区服务和资源'
        ]
      },
      {
        title: '就诊准备的问题',
        type: 'list',
        content: '',
        items: [
          '症状可能是什么原因引起的？',
          '需要进行哪些测试？',
          '是否需要药物治疗？',
          '有哪些非药物干预方法？',
          '如何管理症状？',
          '预期的疾病进展如何？',
          '有哪些可用的支持服务？'
        ]
      },
      {
        title: '后续护理',
        type: 'steps',
        content: '',
        items: [
          '遵循治疗计划',
          '定期随访',
          '随着情况变化调整护理计划',
          '考虑长期护理和法律规划'
        ]
      },
      {
        title: '寻求帮助是力量的表现',
        type: 'highlight',
        content: '面对认知问题，寻求专业帮助是明智和勇敢的决定。早期诊断和干预可以提供更多治疗选择，帮助患者和家人更好地规划未来，并最大限度地提高生活质量。'
      }
    ]
  }
];