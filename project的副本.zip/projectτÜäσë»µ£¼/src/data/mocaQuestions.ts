import { nanoid } from 'nanoid';

export const mocaQuestions = [
  // 视觉空间与执行能力（5分）
  {
    id: nanoid(),
    text: '请将数字和字母按照正确顺序连接起来',
    description: '全部连接正确得1分',
    type: 'connection',
    connectionData: {
      nodes: [
      { id: '1', text: '1', x: 50, y: 50 },
      { id: '2', text: '2', x: 150, y: 80 },
      { id: '3', text: '3', x: 250, y: 50 },
      { id: '4', text: '4', x: 100, y: 120 },
      { id: '5', text: '5', x: 200, y: 150 },
      { id: 'A', text: '甲', x: 70, y: 200 },
      { id: 'B', text: '乙', x: 150, y: 230 },
      { id: 'C', text: '丙', x: 230, y: 200 },
      { id: 'D', text: '丁', x: 100, y: 270 },
      { id: 'E', text: '戊', x: 200, y: 270 }
    ],
    correctSequence: ['1', '2', '3', '4', '5', 'A', 'B', 'C', 'D', 'E']
  },
  options: [
    { id: nanoid(), text: '提交答案', value: 1 }
  ],
},
  {
    id: nanoid(),
    text: '请观察下图中的立方体',
    description: '请从选项中选择一个与原图完全相同的立方体',
    visualAid: 'https://images.pexels.com/photos/1340185/pexels-photo-1340185.jpeg?auto=compress&cs=tinysrgb&w=300',
    type: 'single',
    options: [
      { id: nanoid(), text: '选项A - 缺少线条的立方体', value: 0 },
      { id: nanoid(), text: '选项B - 透视错误的立方体', value: 0 },
      { id: nanoid(), text: '选项C - 与原图完全相同的立方体', value: 1 },
      { id: nanoid(), text: '选项D - 形状扭曲的立方体', value: 0 },
    ],
  },
  {
    id: nanoid(),
    text: '想象如何在钟面画出10点10分',
    description: '请判断以下的描述，正确的是',
    type: 'multiple',
    options: [
      { id: nanoid(), text: '钟面是一个大致的圆形', value: 1 },
      { id: nanoid(), text: '钟面上的数字1到12基本在正确的位置', value: 1 },
      { id: nanoid(), text: '时针指向10，分针指向2（代表10）', value: 1 },
      { id: nanoid(), text: '时针指向10，分针指向10', value: 0 },
      { id: nanoid(), text: '时针指向1，分针指向10', value: 0 },
    ],
  },
  
  // 命名（3分）
  {
    id: nanoid(),
    text: '请看下图，这种动物的名称是',
    visualAid: 'https://images.pexels.com/photos/247502/pexels-photo-247502.jpeg?auto=compress&cs=tinysrgb&w=300',
    type: 'single',
    options: [
      { id: nanoid(), text: '狮子', value: 1 },
      { id: nanoid(), text: '老虎', value: 0 },
      { id: nanoid(), text: '猎豹', value: 0 },
      { id: nanoid(), text: '美洲狮', value: 0 },
    ],
  },
  {
    id: nanoid(),
    text: '请看下图，这种动物的名称是',
    visualAid: 'https://images.pexels.com/photos/667201/pexels-photo-667201.jpeg?auto=compress&cs=tinysrgb&w=300',
    type: 'single',
    options: [
      { id: nanoid(), text: '大象', value: 0 },
      { id: nanoid(), text: '牛', value: 0 },
      { id: nanoid(), text: '犀牛', value: 1 },
      { id: nanoid(), text: '河马', value: 0 },
    ],
  },
  {
    id: nanoid(),
    text: '请看下图，这种动物的名称是',
    visualAid: 'https://images.pexels.com/photos/17472615/pexels-photo-17472615.jpeg?auto=compress&cs=tinysrgb&w=300',
    type: 'single',
    options: [
      { id: nanoid(), text: '羊驼', value: 0 },
      { id: nanoid(), text: '骆驼', value: 1 },
      { id: nanoid(), text: '羊', value: 0 },
      { id: nanoid(), text: '长颈鹿', value: 0 },
    ],
  },
  
  // 记忆（识记阶段）
  {
    id: nanoid(),
    text: '请仔细阅读并努力记住以下五个词语',
    description: '面孔、天鹅绒、教堂、菊花、红色',
    type: 'memory',
    options: [
      { id: nanoid(), text: '面孔', value: 0 },
      { id: nanoid(), text: '天鹅绒', value: 0 },
      { id: nanoid(), text: '教堂', value: 0 },
      { id: nanoid(), text: '菊花', value: 0 },
      { id: nanoid(), text: '红色', value: 0 },
    ],
  },
  
  // 注意力（6分）
  {
    id: nanoid(),
    text: '数字顺背测试',
    description: '接下来将依次显示数字，请仔细观察',
    type: 'sequence',
    sequenceData: {
      items: ['2', '1', '8', '5', '4'],
      displayTime: 2000,
      question: '请选择刚才依次显示的数字序列',
      options: [
        { id: nanoid(), text: '21584', value: 0 },
        { id: nanoid(), text: '21854', value: 1 },
        { id: nanoid(), text: '28154', value: 0 },
      ]
    },
    options: [
      { id: nanoid(), text: '准备好了，开始显示数字', value: 0 }
    ],
  },
  {
    id: nanoid(),
    text: '数字倒背测试',
    description: '接下来将依次显示数字，请仔细观察，之后需要倒序回答',
    type: 'sequence',
    sequenceData: {
      items: ['7', '4', '2'],
      displayTime: 2000,
      question: '请选择刚才显示的数字倒序排列的结果',
      options: [
        { id: nanoid(), text: '274', value: 0 },
        { id: nanoid(), text: '472', value: 0 },
        { id: nanoid(), text: '247', value: 1 },
      ]
    },
    options: [
      { id: nanoid(), text: '准备好了，开始显示数字', value: 0 }
    ],
  },
  {
    id: nanoid(),
    text: '注意力检测',
    description: '在以下数字序列中，数字"1"出现了多少次？5 2 1 9 4 3 8 1 4 8 0 6 2 1 5 1 9 4 5 1 1 4 9 0 5 1 1 2',
    type: 'single',
    options: [
      { id: nanoid(), text: '6次', value: 0 },
      { id: nanoid(), text: '8次', value: 1 },
      { id: nanoid(), text: '9次', value: 0 },
      { id: nanoid(), text: '10次', value: 0 },
    ],
  },
  {
    id: nanoid(),
    text: '连续减7测试',
    description: '从100开始，连续减去5次7，得到的结果序列是',
    type: 'single',
    options: [
      { id: nanoid(), text: '93→86→79→72→65', value: 1 },
      { id: nanoid(), text: '93→85→78→71→64', value: 0 },
      { id: nanoid(), text: '93→86→77→71→64', value: 0 },
      { id: nanoid(), text: '93→86→78→71→64', value: 0 },
      { id: nanoid(), text: '93→86→77→72→64', value: 0 },
    ],
  },
  
  // 语言（3分）
  {
    id: nanoid(),
    text: '句子理解与辨别1',
    description: '请找出与以下句子意思最接近的表达："我只知道今天张亮是来帮过忙的人。"',
    type: 'single',
    options: [
      { id: nanoid(), text: '我知道张亮今天没来帮忙', value: 0 },
      { id: nanoid(), text: '对于今天来帮忙这件事，我唯一确定是张亮参与了', value: 1 },
      { id: nanoid(), text: '张亮是唯一一个今天来帮忙的人', value: 0 },
    ],
  },
  {
    id: nanoid(),
    text: '句子理解与辨别2',
    description: '请找出与以下句子意思最接近的表达："狗在房间的时候，猫总是躲在沙发下面。"',
    type: 'single',
    options: [
      { id: nanoid(), text: '只要狗在房间，猫就会去沙发底下', value: 1 },
      { id: nanoid(), text: '猫喜欢沙发下面，不管狗在不在房间', value: 0 },
      { id: nanoid(), text: '狗和猫从不同时在房间里', value: 0 },
    ],
  },
  {
    id: nanoid(),
    text: '词语流畅性',
    description: '请在30秒内思考尽可能多的动物名称（至少11个不同的动物名称可得分）',
    type: 'single',
    options: [
      { id: nanoid(), text: '我能想到11个或更多不同的动物名称', value: 1 },
      { id: nanoid(), text: '我只能想到不到11个不同的动物名称', value: 0 },
    ],
  },
  
  // 抽象（2分）
  {
    id: nanoid(),
    text: '"火车"和"自行车"的共同点主要是它们都是',
    type: 'single',
    options: [
      { id: nanoid(), text: '交通工具', value: 1 },
      { id: nanoid(), text: '金属制品', value: 0 },
      { id: nanoid(), text: '大型机械', value: 0 },
    ],
  },
  {
    id: nanoid(),
    text: '"手表"和"尺子"的共同点主要是它们都可以用来',
    type: 'single',
    options: [
      { id: nanoid(), text: '显示信息', value: 0 },
      { id: nanoid(), text: '测量', value: 1 },
      { id: nanoid(), text: '佩戴', value: 0 },
    ],
  },
  
  // 延迟回忆（5分）
  {
    id: nanoid(),
    text: '请回忆之前让您记住的五个词语',
    type: 'multiple',
    options: [
      { id: nanoid(), text: '建筑', value: 1 },
      { id: nanoid(), text: '天鹅绒', value: 1 },
      { id: nanoid(), text: '教堂', value: 1 },
      { id: nanoid(), text: '鲜花', value: 1 },
      { id: nanoid(), text: '蓝色', value: 1 },
      { id: nanoid(), text: '桌子', value: 0 },
      { id: nanoid(), text: '红色', value: 0 },
      { id: nanoid(), text: '菊花', value: 0 },
      { id: nanoid(), text: '丝绸', value: 0 },
      { id: nanoid(), text: '面孔', value: 0 },
    ],
  },
  
  // 定向（6分）
{
  id: nanoid(),
  text: '请选择今天的日期是',
  type: 'single',
  dynamicOptions: true,
  getDynamicOptions: () => {
    const today = new Date();
    const day = today.getDate();
    
    return [
      { id: nanoid(), text: `${day-1 || 30}日`, value: 0 },
      { id: nanoid(), text: `${day}日`, value: 1 },
      { id: nanoid(), text: `${day+1 > 31 ? 1 : day+1}日`, value: 0 },
    ];
  },
  options: [
    { id: nanoid(), text: '加载中...', value: 0 },
  ],
},
{
  id: nanoid(),
  text: '请选择当前的月份是',
  type: 'single',
  dynamicOptions: true,
  getDynamicOptions: () => {
    const today = new Date();
    const month = today.getMonth() + 1;
    
    return [
      { id: nanoid(), text: `${month-1 || 12}月`, value: 0 },
      { id: nanoid(), text: `${month}月`, value: 1 },
      { id: nanoid(), text: `${month+1 > 12 ? 1 : month+1}月`, value: 0 },
    ];
  },
  options: [
    { id: nanoid(), text: '加载中...', value: 0 },
  ],
},
{
  id: nanoid(),
  text: '请选择今年的年份是',
  type: 'single',
  dynamicOptions: true,
  getDynamicOptions: () => {
    const today = new Date();
    const year = today.getFullYear();
    
    return [
      { id: nanoid(), text: `${year-1}年`, value: 0 },
      { id: nanoid(), text: `${year}年`, value: 1 },
      { id: nanoid(), text: `${year+1}年`, value: 0 },
    ];
  },
  options: [
    { id: nanoid(), text: '加载中...', value: 0 },
  ],
},
{
  id: nanoid(),
  text: '请选择今天是星期几',
  type: 'single',
  dynamicOptions: true,
  getDynamicOptions: () => {
    const today = new Date();
    const weekday = today.getDay();
    const weekdayNames = ['星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六'];
    
    return weekdayNames.map((name, index) => ({
      id: nanoid(),
      text: name,
      value: index === weekday ? 1 : 0
    }));
  },
  options: [
    { id: nanoid(), text: '加载中...', value: 0 },
  ],
},
{
  id: nanoid(),
  text: '您认为您目前最可能在哪个类型的场所',
  type: 'single',
  options: [
    { id: nanoid(), text: '公园或户外', value: 0 },
    { id: nanoid(), text: '购物中心或市场', value: 0 },
    { id: nanoid(), text: '家中、办公室或类似室内场所', value: 1 },
  ],
},
{
  id: nanoid(),
  text: '您认为您目前所在的城市是',
  type: 'single',
  options: [
    { id: nanoid(), text: '上海', value: 1 },
    { id: nanoid(), text: '广州', value: 0 },
    { id: nanoid(), text: '北京', value: 0 },
    { id: nanoid(), text: '深圳', value: 0 },
  ],
},
];