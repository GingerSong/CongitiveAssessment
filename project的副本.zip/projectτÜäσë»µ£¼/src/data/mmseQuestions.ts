import { nanoid as generateId } from 'nanoid';

const getDateOptions = () => {
  const today = new Date();
  const year = today.getFullYear();
  const month = today.getMonth();
  const date = today.getDate();
  const day = today.getDay();

  // Get season
  const getSeason = (month: number) => {
    if (month >= 2 && month <= 4) return '春季';
    if (month >= 5 && month <= 7) return '夏季';
    if (month >= 8 && month <= 10) return '秋季';
    return '冬季';
  };
  const currentSeason = getSeason(month);

  // Get month name
  const monthNames = ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'];
  const currentMonth = monthNames[month];

  // Get weekday name
  const weekdayNames = ['星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六'];
  const currentWeekday = weekdayNames[day];

  return {
    years: [
      { id: generateId(), text: `${year - 1}年`, value: 0 },
      { id: generateId(), text: `${year}年`, value: 1 },
      { id: generateId(), text: `${year + 1}年`, value: 0 },
      { id: generateId(), text: '以上都不是', value: 0 },
    ],
    seasons: [
      { id: generateId(), text: '春季', value: currentSeason === '春季' ? 1 : 0 },
      { id: generateId(), text: '夏季', value: currentSeason === '夏季' ? 1 : 0 },
      { id: generateId(), text: '秋季', value: currentSeason === '秋季' ? 1 : 0 },
      { id: generateId(), text: '冬季', value: currentSeason === '冬季' ? 1 : 0 },
      { id: generateId(), text: '以上都不是', value: 0 },
    ],
    months: [
      { id: generateId(), text: monthNames[(month - 1 + 12) % 12], value: 0 },
      { id: generateId(), text: currentMonth, value: 1 },
      { id: generateId(), text: monthNames[(month + 1) % 12], value: 0 },
      { id: generateId(), text: '以上都不是', value: 0 },
    ],
    dates: [
      { id: generateId(), text: `${date - 1}日`, value: 0 },
      { id: generateId(), text: `${date}日`, value: 1 },
      { id: generateId(), text: `${date + 1}日`, value: 0 },
      { id: generateId(), text: '以上都不是', value: 0 },
    ],
    weekdays: [
      { id: generateId(), text: weekdayNames[(day - 1 + 7) % 7], value: 0 },
      { id: generateId(), text: currentWeekday, value: 1 },
      { id: generateId(), text: weekdayNames[(day + 1) % 7], value: 0 },
      { id: generateId(), text: '以上都不是', value: 0 },
    ],
  };
};

export const mmseQuestions = () => {
  const dateOpts = getDateOptions();
  
  return [
    // 定向力 - 时间（5分）
    {
      id: generateId(),
      text: '请选择今年的年份是',
      type: 'single',
      options: dateOpts.years,
    },
    {
      id: generateId(),
      text: '请选择当前的季节是',
      type: 'single',
      options: dateOpts.seasons,
    },
    {
      id: generateId(),
      text: '请选择当前的月份是',
      type: 'single',
      options: dateOpts.months,
    },
    {
      id: generateId(),
      text: '请选择今天的日期是',
      type: 'single',
      options: dateOpts.dates,
    },
    {
      id: generateId(),
      text: '请选择今天是星期几',
      type: 'single',
      options: dateOpts.weekdays,
    },
    
    // 定向力 - 地点（5分）
    {
      id: generateId(),
      text: '您认为您目前所在的国家是',
      type: 'single',
      options: [
        { id: generateId(), text: '美国', value: 0 },
        { id: generateId(), text: '中国', value: 1 },
        { id: generateId(), text: '日本', value: 0 },
        { id: generateId(), text: '英国', value: 0 },
        { id: generateId(), text: '以上都不是', value: 0 },
      ],
    },
    {
      id: generateId(),
      text: '您认为您目前所在的城市是',
      type: 'single',
      options: [
        { id: generateId(), text: '上海', value: 0 },
        { id: generateId(), text: '广州', value: 0 },
        { id: generateId(), text: '北京', value: 1 },
        { id: generateId(), text: '深圳', value: 0 },
        { id: generateId(), text: '以上都不是', value: 0 },
      ],
    },
    {
      id: generateId(),
      text: '您认为您目前所在的区/县是',
      type: 'single',
      options: [
        { id: generateId(), text: '朝阳区', value: 0 },
        { id: generateId(), text: '海淀区', value: 1 },
        { id: generateId(), text: '西城区', value: 0 },
        { id: generateId(), text: '丰台区', value: 0 },
        { id: generateId(), text: '以上都不是', value: 0 },
      ],
    },
    {
      id: generateId(),
      text: '您认为您目前所在的具体场所类型最可能是',
      type: 'single',
      options: [
        { id: generateId(), text: '购物中心', value: 0 },
        { id: generateId(), text: '公园', value: 0 },
        { id: generateId(), text: '家/医院/体检中心', value: 1 },
        { id: generateId(), text: '学校', value: 0 },
        { id: generateId(), text: '以上都不是', value: 0 },
      ],
    },
    {
      id: generateId(),
      text: '如果您在一栋多层建筑内，您估计自己目前在第几层楼',
      type: 'single',
      options: [
        { id: generateId(), text: '1-2层', value: 0 },
        { id: generateId(), text: '3-5层', value: 1 },
        { id: generateId(), text: '6-8层', value: 0 },
        { id: generateId(), text: '不确定/地面层', value: 0 },
        { id: generateId(), text: '以上都不是', value: 0 },
      ],
    },
    
    // 记忆力测试（3分）
    {
      id: generateId(),
      text: '请仔细记住以下三个词语：皮球、国旗、树木',
      description: '皮球、国旗、树木',
      type: 'memory',
      options: [
        { id: generateId(), text: '皮球', value: 1 },
        { id: generateId(), text: '国旗', value: 1 },
        { id: generateId(), text: '树木', value: 1 },
      ],
    },
    
    // 注意力和计算力（5分）
    {
      id: generateId(),
      text: '请从100开始，依次减去7，进行连续5次计算',
      type: 'single',
      options: [
        { id: generateId(), text: '93→86→79→72→65', value: 5 },
        { id: generateId(), text: '93→87→80→73→66', value: 0 },
        { id: generateId(), text: '93→85→77→69→61', value: 0 },
        { id: generateId(), text: '93→86→78→70→63', value: 2 },
        { id: generateId(), text: '以上都不是', value: 0 },
      ],
    },
    
    // 回忆力（3分）
    {
      id: generateId(),
      text: '请回忆之前让您记住的三个词语',
      type: 'multiple',
      options: [
        { id: generateId(), text: '飞机', value: 0 },
        { id: generateId(), text: '皮球', value: 1 },
        { id: generateId(), text: '电脑', value: 0 },
        { id: generateId(), text: '国旗', value: 1 },
        { id: generateId(), text: '树木', value: 1 },
        { id: generateId(), text: '房子', value: 0 },
      ],
    },
    
    // 语言能力 - 物体命名（2分）
    {
      id: generateId(),
      text: '请看下图，选择这个物品的名称',
      visualAid: 'https://images.pexels.com/photos/372748/pexels-photo-372748.jpeg?auto=compress&cs=tinysrgb&w=300',
      type: 'single',
      options: [
        { id: generateId(), text: '铅笔', value: 0 },
        { id: generateId(), text: '毛笔', value: 0 },
        { id: generateId(), text: '钢笔', value: 1 },
        { id: generateId(), text: '圆珠笔', value: 0 },
        { id: generateId(), text: '以上都不是', value: 0 },
      ],
    },
    {
      id: generateId(),
      text: '请看下图，选择这个物品的名称',
      visualAid: 'https://images.pexels.com/photos/280250/pexels-photo-280250.jpeg?auto=compress&cs=tinysrgb&w=300',
      type: 'single',
      options: [
        { id: generateId(), text: '手镯', value: 0 },
        { id: generateId(), text: '手表', value: 1 },
        { id: generateId(), text: '指南针', value: 0 },
        { id: generateId(), text: '闹钟', value: 0 },
        { id: generateId(), text: '以上都不是', value: 0 },
      ],
    },
    
    // 语言能力 - 句子重复（1分）
    {
      id: generateId(),
      text: '请仔细记住以下短语和顺序',
      description: '如果、并且、但是',
      type: 'memory',
      options: [
        { id: generateId(), text: '如果、或者、但是', value: 0 },
        { id: generateId(), text: '如果、并且、但是', value: 1 },
        { id: generateId(), text: '并且、如果、但是', value: 0 },
        { id: generateId(), text: '如果、并且、或者', value: 0 },
        { id: generateId(), text: '以上都不是', value: 0 },
      ],
    },
    
    // 三步指令（3分）
    {
      id: generateId(),
      text: '假设您面前有一张纸，请阅读以下三个操作指令，并选择正确的操作顺序',
      description: '指令1：用两只手把纸对折起来。指令2：将对折好的纸放在您的左腿上。指令3：用您的右手拿起这张纸。',
      type: 'single',
      options: [
        { id: generateId(), text: '指令1 -> 指令2 -> 指令3', value: 0 },
        { id: generateId(), text: '指令3 -> 指令1 -> 指令2', value: 3 },
        { id: generateId(), text: '指令2 -> 指令3 -> 指令1', value: 0 },
        { id: generateId(), text: '指令3 -> 指令2 -> 指令1', value: 0 },
        { id: generateId(), text: '以上都不是', value: 0 },
      ],
    },
    
    // 回忆力（1分）
    {
      id: generateId(),
      text: '请回忆之前让您记住的三个词语和顺序',
      type: 'single',
      options: [
        { id: generateId(), text: '如果、或者、但是', value: 0 },
        { id: generateId(), text: '如果、并且、但是', value: 1 },
        { id: generateId(), text: '并且、如果、但是', value: 0 },
        { id: generateId(), text: '如果、并且、或者', value: 0 },
        { id: generateId(), text: '以上都不是', value: 0 },
      ],
    },

    // 阅读（1分）
    {
      id: generateId(),
      text: '阅读理解',
      description: '接下来将依次显示文字，请仔细观察',
      type: 'sequence',
      sequenceData: {
        items: ['请', '闭', '上', '眼', '睛'],
        displayTime: 2000,
        question: '请选择刚才显示的文字的意思',
        options: [
          { id: generateId(), text: '阅读这句话', value: 0 },
          { id: generateId(), text: '闭上眼睛', value: 1 },
          { id: generateId(), text: '思考这句话的含义', value: 0 },
          { id: generateId(), text: '忽略这句话', value: 0 },
          { id: generateId(), text: '以上都不是', value: 0 },
        ]
      },
      options: [
        { id: generateId(), text: '准备好了，开始显示文字', value: 0 }
      ],
    },

    // 书写（1分）
    {
      id: generateId(),
      text: '请判断下列哪个句子是结构完整且有明确意义的句子？',
      type: 'single',
      options: [
        { id: generateId(), text: '快速奔跑的。', value: 0 },
        { id: generateId(), text: '小猫在睡觉。', value: 1 },
        { id: generateId(), text: '在那张桌子非常。', value: 0 },
        { id: generateId(), text: '因为下雨所以。', value: 0 },
        { id: generateId(), text: '以上都不是', value: 0 },
      ],
    },
    
    // 绘图（1分）
    {
      id: generateId(),
      text: '请仔细观察下图A中的图案。然后从选项B、C、D、E中，选择一个与图A完全相同的图案',
      visualAid: 'https://images.pexels.com/photos/5428836/pexels-photo-5428836.jpeg?auto=compress&cs=tinysrgb&w=300',
      type: 'single',
      options: [
        { id: generateId(), text: '选项B - 一个五边形与一个六边形交叉', value: 0 },
        { id: generateId(), text: '选项C - 两个五边形，但不交叉', value: 0 },
        { id: generateId(), text: '选项D - 与图A完全相同的两个交叉五边形', value: 1 },
        { id: generateId(), text: '选项E - 两个五边形交叉，但形状变形', value: 0 },
        { id: generateId(), text: '以上都不是', value: 0 },
      ],
    },
  ];
};